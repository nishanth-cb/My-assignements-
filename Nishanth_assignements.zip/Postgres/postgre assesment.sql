-- Create tblUsers table
CREATE TABLE tblUsers (
    User_id SERIAL PRIMARY KEY,
    User_name VARCHAR(255),
    Email VARCHAR(255)
);

-- Insert data into tblUsers
INSERT INTO tblUsers (User_id, User_name, Email) VALUES
    (1001, 'Akash', 'akash@gmail.com'),
    (1002, 'Arvind', 'arvind123@gmail.com'),
    (1003, 'Sakshi', 'sakshimys12@gmail.com'),
    (1004, 'Kumar', 'kumar987@gmail.com');

-- Create tblCategory table
CREATE TABLE tblCategory (
    Category_id SERIAL PRIMARY KEY,
    Category_name VARCHAR(255),
    Description VARCHAR(255)
);

-- Insert data into tblCategory
INSERT INTO tblCategory (Category_id, Category_name, Description) VALUES
    (201, 'Electronics', 'One stop for electronic items.'),
    (202, 'Apparel', 'Apparel is the next destination for fashion.'),
    (203, 'Grocery', 'All needs in one place.');

-- Create tblProducts table
CREATE TABLE tblProducts (
    Product_id SERIAL PRIMARY KEY,
    Product_name VARCHAR(255),
    Quantity INT,
    Product_price DECIMAL(10, 2),
    Category_id INT REFERENCES tblCategory(Category_id)
);

-- Insert data into tblProducts
INSERT INTO tblProducts (Product_id, Product_name, Quantity, Product_price, Category_id) VALUES
    (1, 'Mobile Phone', 1000, 15000.00, 201),
    (2, 'Television', 500, 40000.00, 201),
    (3, 'Denims', 2000, 700.00, 202),
    (4, 'Vegetables', 4000, 40.00, 203),
    (5, 'Ethnic Wear', 300, 1500.00, 202),
    (6, 'Wireless Earphone', 5000, 2500.00, 201),
    (7, 'Lounge Wear', 200, 1600.00, 202),
    (8, 'Refrigerator', 50, 30000.00, 201),
    (9, 'Pulses', 60, 150.00, 202),
    (10, 'Fruits', 100, 250.00, 202);

-- Create tblSales table
CREATE TABLE tblSales (
    Sales_id SERIAL PRIMARY KEY,
    Sales_user_id INT REFERENCES tblUsers(User_id),
    Product_id INT REFERENCES tblProducts(Product_id)
);

-- Insert data into tblSales
INSERT INTO tblSales (Sales_id, Sales_user_id, Product_id) VALUES
    (500, 1001, 1),
    (501, 1002, 1),
    (502, 1003, 2),
    (504, 1004, 3),
    (505, 1004, 1),
    (506, 1004, 1),
    (507, 1002, 2),
    (508, 1003, 1),
    (509, 1001, 7),
    (510, 1001, 8);




-- 1.Write a function to fetch the names of the product,category and users along with the cost for each 
-- product sold 
-- depending on the sales_id. 
-- Also if the cost for each product is more than 2000, then display a message stating 
-- that 'The product has gained profit'.  
-- If the product cost is between 500 and 1000, then raise a message stating that 
-- 'The product has occured loss'.  
-- If the product cost is less than 500, then raise an exception stating 'No profit no loss'
CREATE OR REPLACE FUNCTION fetch_productdtls(saleid INT)
RETURNS TABLE (
    product_name VARCHAR(255),
    category_name VARCHAR(255),
    user_name VARCHAR(255),
    product_cost DECIMAL(10, 2)
)
AS $$
BEGIN
    BEGIN
        -- Wrap the SQL query in a BEGIN...EXCEPTION...END block
        SELECT p.product_name, c.category_name, u.user_name, p.product_price
        INTO product_name, category_name, user_name, product_cost
        FROM tblSales s
        INNER JOIN tblUsers u ON s.sales_user_id = u.user_id
        INNER JOIN tblProducts p ON s.product_id = p.product_id
        INNER JOIN tblCategory c ON p.category_id = c.category_id
        WHERE s.sales_id = saleid;

    EXCEPTION
        WHEN OTHERS THen
            RAISE EXCEPTION 'Error in SQL query: %', SQLERRM;
    END;

    IF product_cost > 2000 THEN
        RAISE INFO 'The product has gained profit';
    ELSIF product_cost BETWEEN 500 AND 1000 THEN
        RAISE INFO 'The product has occurred loss';
    ELSIF product_cost < 500 THEN
        RAISE EXCEPTION 'No profit no loss';
    END IF;

    RETURN NEXT;
END
$$ LANGUAGE plpgsql;

SELECT * FROM fetch_productdtls(500);


SELECT * FROM tblUsers
 SELECT * FROM tblCategory
 SELECT * FROM tblProducts
 SELECT * FROM tblSales





 


DROP FUNCTION IF EXISTS fetch_product_details_with_profit_loss(integer);









-- 2.Write a procedure to update the name of the category from 'Electronics' to 'Modern Gadgets' and 
-- also  
-- fetch the category and product names when the userid is passed as the input parameter. 



CREATE OR REPLACE PROCEDURE usp_update(
    userid_ INT,
    OUT category_ VARCHAR(20),
    OUT product_ VARCHAR(30)
)
LANGUAGE PLPGSQL
AS $$
BEGIN
    -- Check  user has sales records
    PERFORM 1
    FROM tblsales
    WHERE Sales_user_id = userid_;

    -- If no sales records, raise  exception
    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER BOUGHT NOTHING IN THE STORE';
    END IF;

    -- Start  transaction
    BEGIN
        -- Update category name
        UPDATE tblcategory
        SET Category_name = 'Modern Gadgets'
        WHERE Category_name = 'Electronics';

        -- Retrieve category and product info
        SELECT C.category_name, P.Product_name
        INTO category_, product_
        FROM tablcategory C
        INNER JOIN tblproducts P ON C.category_id = P.category_id
        INNER JOIN tblsales S ON S.product_id = P.product_id
        WHERE S.Sales_user_id = userid_;
    EXCEPTION
        WHEN OTHERS THEN
            -- Handle exceptions
            RAISE EXCEPTION 'An error occurred: %', SQLERRM;
    END;

    -- Commit the transaction
    COMMIT;
END;
$$;




CALL C_UPDATE(1004);

SELECT * FROM tblUsers
 SELECT * FROM tblCategory
 SELECT * FROM tblProducts
 SELECT * FROM tblSales


-- CREATE OR REPLACE FUNCTION fetch_productdtls(saleid INT)
-- RETURNS TABLE (
--     product_name VARCHAR(255),
--     category_name VARCHAR(255),
--     user_name VARCHAR(255),
--     product_cost DECIMAL(10, 2)
-- )
-- AS $$
-- BEGIN
--     SELECT p.product_name, c.category_name, u.user_name, p.product_price
--     INTO product_name, category_name, user_name, product_cost
--     FROM tblSales s
--     INNER JOIN tblUsers u ON s.sales_user_id = u.user_id
--     INNER JOIN tblProducts p ON s.product_id = p.product_id
--     INNER JOIN tblCategory c ON p.category_id = c.category_id
--     WHERE s.sales_id = saleid;

--     IF product_cost > 2000 THEN
--         RAISE INFO 'The product has gained profit';
--     ELSIF product_cost BETWEEN 500 AND 1000 THEN
--         RAISE INFO 'The product has occurred loss';
--     ELSIF product_cost < 500 THEN
--         RAISE EXCEPTION 'No profit no loss';
--     END IF;

--     RETURN NEXT;
-- END
-- $$ LANGUAGE plpgsql;


-- 










-- raj
-- CREATE OR REPLACE PROCEDURE usp_update(
--     userid_ INT,
--     OUT category_ VARCHAR(20),
--     OUT product_ VARCHAR(30)
-- )
-- LANGUAGE PLPGSQL
-- AS $$
-- BEGIN
--     BEGIN
--         -- Check if the user has sales records
--         IF NOT EXISTS (SELECT 1 FROM tblsales WHERE Sales_user_id = userid_) THEN
--             RAISE EXCEPTION 'USER BOUGHT NOTHING IN THE STORE';
--         END IF;

--         -- Update category name
--         UPDATE tblcategory
--         SET Category_name = 'Modern Gadgets'
--         WHERE Category_name = 'Electronics';

--         -- Retrieve category and product information
--         SELECT C.category_name, P.Product_name
--         INTO category_, product_
--         FROM tablcategory C
--         INNER JOIN tblproducts P ON C.category_id = P.category_id
--         INNER JOIN tblsales S ON S.product_id = P.product_id
--         WHERE S.Sales_user_id = userid_;

--     EXCEPTION
--         WHEN OTHERS THEN
--             -- Handle exceptions
--             RAISE EXCEPTION 'An error occurred: %', SQLERRM;
--     END;

-- END;
-- $$;


CREATE OR REPLACE PROCEDURE update_category_and_fetch_products(user_id_param INT)
AS $$
DECLARE
    new_category_name VARCHAR(255) := 'Modern Gadgets';
    category_and_product RECORD;
BEGIN
    -- Update the name of the category
    UPDATE tblCategory
    SET category_name = new_category_name
    WHERE category_name = 'Electronics';

    -- Fetch category and product names for the given user_id
    FOR category_and_product IN
        SELECT c.category_name, p.product_name
        FROM tblSales s
        INNER JOIN tblUsers u ON s.sales_user_id = u.user_id
        INNER JOIN tblProducts p ON s.product_id = p.product_id
        INNER JOIN tblCategory c ON p.category_id = c.category_id
        WHERE u.user_id = user_id_param
    LOOP
        RAISE NOTICE 'Category: %, Product: %', category_and_product.category_name, category_and_product.product_name;
    END LOOP;
END $$ LANGUAGE plpgsql;










-- CREATE OR REPLACE PROCEDURE update_category_and_fetch_products(
--     user_id_param INT,
--     OUT result_category_name VARCHAR(255),
--     OUT result_product_name VARCHAR(255)
-- )
-- AS $$
-- BEGIN
--     -- Update the name of the category
--     UPDATE tblCategory
--     SET category_name = 'Modern Gadgets'
--     WHERE category_name = 'Electronics';

--     -- Fetch and set the output parameters
--     SELECT c.category_name, p.product_name
--     INTO result_category_name, result_product_name
--     FROM tblSales s
--     INNER JOIN tblUsers u ON s.sales_user_id = u.user_id
--     INNER JOIN tblProducts p ON s.product_id = p.product_id
--     INNER JOIN tblCategory c ON p.category_id = c.category_id
--     WHERE u.user_id = user_id_param;
    
--     -- Indicate the end of the output
--     RAISE NOTICE 'END OF OUTPUT';
-- END $$ LANGUAGE plpgsql;


-- DROP PROCEDURE IF EXISTS update_category_and_fetch_products(integer);

-- DO $$ 
-- DECLARE 
--     category_name_result VARCHAR(255);
--     product_name_result VARCHAR(255);
-- BEGIN 
--     CALL update_category_and_fetch_products(1001, category_name_result, product_name_result);
--     RAISE NOTICE 'Category: % | Product: %', category_name_result, product_name_result;
-- END $$;








-- CREATE OR REPLACE  PROCEDURE C_UPDATE( IN U_ID INT,
--   INOUT C_NAME VARCHAR(30) DEFAULT NULL,
--   INOUT P_NAME VARCHAR(30) DEFAULT NULL)
-- LANGUAGE PLPGSQL
-- AS $$
-- BEGIN
-- UPDATE  tblcategory
-- SET Category_Name='Modern Gadgets'
-- WHERE Category_Name='Electronics';

-- SELECT
-- P.Product_Name INTO P_NAME
-- FROM
-- tblSales s INNER JOIN tblProducts p USING(Product_Id)
-- INNER JOIN tblCategory c USING(Category_Id)
-- WHERE s.Sales_user_id=U_ID;


-- SELECT
-- C.Category_Name INTO C_NAME
-- FROM
-- tblSales s INNER JOIN tblProducts p USING(Product_Id)
-- INNER JOIN tblCategory c USING(Category_Id)
-- WHERE s.Sales_user_id=U_ID;


-- END;$$













-- CREATE OR REPLACE PROCEDURE update_category_and_fetch_products(user_id_param INT)
-- AS $$
-- DECLARE
--     new_category_name VARCHAR(255) := 'Modern Gadgets';
--     category_and_product RECORD;
-- BEGIN
--     UPDATE tblCategory
--     SET category_name = new_category_name
--     WHERE category_name = 'Electronics';

--     FOR category_and_product IN
--         SELECT c.category_name, p.product_name
--         FROM tblSales s
--         INNER JOIN tblUsers u ON s.sales_user_id = u.user_id
--         INNER JOIN tblProducts p ON s.product_id = p.product_id
--         INNER JOIN tblCategory c ON p.category_id = c.category_id
--         WHERE u.user_id = user_id_param
--     LOOP
--         RAISE NOTICE 'Category: % | Product: %', category_and_product.category_name, category_and_product.product_name;
--     END LOOP;

--     RAISE NOTICE 'END OF OUTPUT';
-- END $$ LANGUAGE plpgsql;



-- CALL update_category_and_fetch_products(1002);
