-- Create tbldirectors table
CREATE TABLE tbldirectors (
    director_id SERIAL PRIMARY KEY,
    first_name VARCHAR(150) NOT NULL,
    last_name VARCHAR(150) NOT NULL
);

-- Create tblmovies table
CREATE TABLE tblmovies (
    movie_id SERIAL PRIMARY KEY,
    movie_name VARCHAR(100) NOT NULL,
    movie_length INTEGER NOT NULL,
    movie_lang VARCHAR(20) NOT NULL,
    movie_certificate VARCHAR(20) NOT NULL,
    release_date DATE NOT NULL,
    director_id INTEGER REFERENCES tbldirectors(director_id)
);

-- Create tblactors table
CREATE TABLE tblactors (
    actor_id SERIAL PRIMARY KEY,
    first_name VARCHAR(150) NOT NULL,
    last_name VARCHAR(150) NOT NULL,
    gender CHAR(5),
    date_of_birth DATE NOT NULL,
    movie_id INTEGER REFERENCES tblmovies(movie_id)
);

-- Insert data into tbldirectors
INSERT INTO tbldirectors (first_name, last_name) VALUES
    ('Christopher', 'Nolan'),
    ('Steven', 'Spielberg'),
    ('Quentin', 'Tarantino'),
    ('Greta', 'Gerwig'),
    ('Martin', 'Scorsese'),
    ('Patty', 'Jenkins'),
    ('Rajkumar', 'Hirani'),
    ('S. S.', 'Rajamouli'),
    ('Nagathihalli', 'Chandrashekhar'),
    ('Pawan', 'Kumar');

-- Insert data into tblmovies
INSERT INTO tblmovies (movie_name, movie_length, movie_lang, movie_certificate, release_date, director_id) VALUES
    ('Inception', 148, 'English', 'PG-13', '2010-07-16', 1),
    ('Jurassic Park', 127, 'English', 'PG-13', '1993-06-11', 2),
    ('Pulp Fiction', 154, 'English', 'R', '1994-10-14', 3),
    ('Lady Bird', 94, 'English', 'R', '2017-11-03', 4),
    ('The Irishman', 209, 'English', 'R', '2019-11-01', 5),
    ('Wonder Woman', 141, 'English', 'PG-13', '2017-05-15', 6),
    ('3 Idiots', 170, 'Hindi', 'PG-13', '2009-12-25', 7),
    ('Baahubali: The Beginning', 159, 'Telugu', 'PG-13', '2015-07-10', 8),
    ('America America', 168, 'Kannada', 'PG', '1995-07-14', 9),
    ('Lucia', 135, 'Kannada', 'PG-13', '2013-09-06', 10);

-- Insert data into tblactors
INSERT INTO tblactors (first_name, last_name, gender, date_of_birth, movie_id) VALUES
    ('Leonardo', 'DiCaprio', 'M', '1974-11-11', 1),
    ('Tom', 'Hanks', 'M', '1956-07-09', 2),
    ('John', 'Travolta', 'M', '1954-02-18', 3),
    ('Saoirse', 'Ronan', 'F', '1994-04-12', 4),
    ('Robert', 'De Niro', 'M', '1943-08-17', 5),
    ('Gal', 'Gadot', 'F', '1985-04-30', 6),
    ('Aamir', 'Khan', 'M', '1965-03-14', 7),
    ('Prabhas', 'Raju', 'M', '1979-10-23', 8),
    ('Ramesh', 'Aravind', 'M', '1964-09-10', 9),
    ('Sathish', 'Ninasam', 'M', '1986-06-20', 10);





























 --1.Display Movie name, movie language and release date from movies table. 
SELECT movie_name, movie_lang, release_date from tblmovies

--2.Display only 'Kannada' movies from movies table. 
Select movie_name from tblmovies WHERE movie_lang='English'

--3.Display movies released before 1st Jan 2011. 
SELECT * FROM tblmovies WHERE release_date < '2011-01-01';

--5.Display movies of director id 3 or Kannada language. 
SELECT * from tblmovies 
where director_id=3 or movie_lang='Kannada'


--4.Display Hindi movies with movie duration more than 150 minutes.
SELECT *
FROM tblmovies
WHERE movie_lang = 'English' AND movie_length > 150;

--6.Display movies released in the year 2023. 
SELECT * FROM tblmovies
where extract (Year from release_date)=2023

--7.Display movies that can be watched below 15 years.
 select * from tblmovies 
WHERE movie_certificate = 'PG-13' 

--8.Display movies that are released after the year 2015 and directed by directorid 3. 

SELECT *
FROM tblmovies
WHERE release_date > '2015-01-01' AND director_id = 3;

--9.Display all other language movies except Hindi language. 

SELECT * FROM tblmovies
where movie_lang<>'Hindi'

--10.Display movies whose language name ends with 'u'. 

SELECT * FROM tblmovies 
where movie_lang like '%u'

--11.Display movies whose language starts with 'm'. 

SELECT * from tblmovies 
where movie_lang like 'm%'

--12.Display movies with language name that has only 5 characters. 

SELECT * from tblmovies 
where movie_lang like '_____'

--13.Display the actors who were born before the year 1980.

SELECT * from tblactors 
where extract (year from date_of_birth) < '1980'

--14.Display the youngest actor from the actors table.

select * from tblactors 
ORDER BY date_of_birth DESC
LIMIT 1;


--15 Display the oldest actor from the actors table. 

select * from tblactors 
ORDER BY date_of_birth ASC
LIMIT 1;

--16 Display all the female actresses whose ages are between 30 and 35. 

SELECT * FROM tblactors 
where gender='F' AND EXTRACT(YEAR FROM age(NOW(), date_of_birth))BETWEEN 30 AND 35 


--17 Display the actors whose movie ids are in 1 to 5. 
SELECT * FROM tblactors
WHERE movie_id IN (1,2,3,4,5)

--18.Display the longest duration movie from movies table. 

SELECT * FROM tblmovieS
ORDER BY  movie_length DESC
LIMIT 1

--19.Display the shortest duration movie from movies table. 

SELECT * FROM tblmovieS
ORDER BY  movie_length ASC 
LIMIT 1

--20.Display the actors whose name starts with vowels. 
SELECT *
FROM tblactors
WHERE LOWER (SUBSTRING(first_name,1,1)) in ('a','e','i','o','u')


SELECT *
FROM tblactors
WHERE LOWER(first_name) like 'a%' OR
	  LOWER(first_name) like 'e%' OR
	  LOWER(first_name) like 'i%' OR
	  LOWER(first_name) like 'o%' OR
	  LOWER(first_name) like 'u%' 


--21.Display all the records from tblactors by sorting the data based on the fist_name in the 
--ascending order and date of birth in the descending order. 

select * from tblactors 
order by first_name asc , date_of_birth desc
 
--22.Write a query to  return the data related to movies by arranging the data in ascending order 
--based on the movie_id and also fetch the data from the fifth value to the twentieth value. 

select * from tblmovies 
order by movie_id asc 
OFFSET 4 
LIMIT 16
-----------------------------------------------------------------------------------------------------------------
----------------------------------PART2___________________________________________________________________________________



-- List the different languages of movies. 
select distinct movie_lang
from tblmovies

-- 2.Display the unique first names of all directors in ascending order by 
-- their first name and then for each group of duplicates, keep the first row in the 
-- returned result set. 

SELECT DISTINCT ON (first_name)
    first_name, last_name
FROM tbldirectors
ORDER BY first_name ASC;


-- 3. write a query to retrieve 4 records starting from the fourth one, to 
-- display the actor ID, name (first_name, last_name) and date of birth, and 
-- arrange the result as Bottom N rows from the actors table according to their 
-- date of birth. 

SELECT actor_id, first_name, last_name, date_of_birth
FROM tblactors
ORDER BY date_of_birth DESC
OFFSET 3 
LIMIT 4;  


-- 4.Write a query to get the first names of the directors who holds the letter 
-- 'S' or 'J' in the first name.  

SELECT first_name 
from tbldirectors
where  lower(first_name) like '%s%' OR  lower(first_name) like '%j%'


-- 5.Write a query to find the movie name and language of the movie of all 
-- the movies where the director name is Joshna. 
 
SELECT m.movie_name, m.movie_lang
from tblmovies m inner join tbldirectors d on m.director_id= d.director_id
where d.first_name = 'Joshna' or d.last_name = 'Joshna'


-- 6.Write a query to find the number of directors available in the movies 
-- table. 

Select count( distinct director_id)
from tblmovies


-- 7. Write a query to find the total length of the movies available in the 
-- movies table. 


SELECT SUM(movie_length) AS TOTAL 
FROM tblmovies

-- 8.Write a query to get the average of movie length for all the directors 
-- who are working for more than 1 movie. 


SELECT d.director_id, d.first_name, d.last_name, AVG(m.movie_length) AS average_movie_length
FROM tbldirectors d
INNER JOIN tblmovies m ON d.director_id = m.director_id
GROUP BY d.director_id, d.first_name, d.last_name
HAVING COUNT(m.movie_id) > 1;



-- 9.Write a query to find the age of the actor vijay for the year 2001-04-10.

SELECT actor_id, first_name, last_name,
       AGE('2001-04-10'::DATE,date_of_birth) as age
FROM tblactors
WHERE first_name = 'Vijay';


-- 10.Write a query to fetch the week of this release date 2020-10-10 
-- 13:00:10. 
SELECT release_date,
    to_char(release_date,'dd') AS release_week
FROM tblmovies
WHERE release_date = '2020-10-10 13:00:10';



        
-- 11.Write a query to fetch the day of the week and year for this release date 
-- 2020-10-10 13:00:10.        
SELECT
    release_date,
    TO_CHAR(release_date, 'Day') AS RELEASE_DAY,
    TO_CHAR(release_date, 'YYYY') AS RELEASE_year
FROM  tblmovies
WHERE release_date = '2010-07-16';

	
	
-- 12.Write a query to convert the given string '20201114' into date and time. 

SELECT TO_date('20201114', 'YYYYMMDD');

-- 13.Display Today's date. 
SELECT CURRENT_DATE;

-- 14.Display Today's date with time. 
SELECT CURRENT_DATE,CURRENT_TIME;

-- 15.Write a query to add 10 Days 1 Hour 15 Minutes to the current date. 

SELECT CURRENT_TIMESTAMP + INTERVAL '10 days 1 hour 15 minutes';

-- 16.Write a query to find the details of those actors who contain eight or 
-- more characters in their first name.


 SELECT * FROM tblactors
 where length(first_name)>=8

-- 17.Write a query to join the text 'movie' with the movie_name column. 

SELECT 'movie'|| movie_name from tblmovies


-- 18.Write a query to get the actor id, first name and birthday month of an 
-- actor. 

SELECT actor_id, first_name, TO_CHAR(date_of_birth, 'Month')  as birthmonth
from tblactors



-- 19.Write a query to get the actor id, last name to discard the last three 
-- characters. 


SELECT  actor_id, LEFT(last_name, LENGTH(last_name) - 3) AS trimmed_last_name
FROM tblactors;



-- 20.Write a query that displays the first name and the character length of 
-- the first name for all directors whose name starts with the letters 'A', 'J' or 'V'. 
-- Give each column an appropriate label. Sort the results by the directors' first 
-- names. 


 
SELECT first_name AS director_first_name, LENGTH(first_name) AS first_name_length
FROM tbldirectors
WHERE first_name LIKE 'A%' OR first_name LIKE 'J%' OR first_name LIKE 'V%'
ORDER BY  first_name;


-- 21.Write a query to display the first word in the movie name if the movie 
-- name contains more than one words. 

SELECT movie_name,  SPLIT_PART(movie_name, ' ', 1) AS first_word
FROM  tblmovies
WHERE POSITION(' ' IN movie_name) > 0;
 

-- 22.Write a query to display the actors name with movie name.       


SELECT a.first_name || ' ' || a.last_name AS actor_name,  m.movie_name
FROM tblactors a
INNER JOIN tblmovies m ON a.movie_id = m.movie_id;



-- 23.Write a query to make a join with three tables movies, actors, and 
-- directors to display the movie name, director name, and actors date of birth. 

SELECT m.movie_name, d.first_name || ' ' || d.last_name AS director_name,
    a.date_of_birth AS actor_date_of_birth
FROM tblmovies m
INNER JOIN tbldirectors d ON m.director_id = d.director_id
INNER JOIN tblactors a ON m.movie_id = a.movie_id;





-- 24.Write a query to make a join with two tables directors and movies to 
-- display the status of directors who is currently working for the movies above 1


SELECT d.director_id, d.first_name || ' ' || d.last_name AS director_name,  m.movie_name,
    CASE WHEN m.release_date > CURRENT_DATE THEN 'Upcoming'
         WHEN m.release_date <= CURRENT_DATE THEN 'Released'
         ELSE 'Not available'
    END AS movie_status
FROM tbldirectors d
INNER JOIN  tblmovies m ON d.director_id = m.director_id;


 
 
 
-- 25.Write a query to make a join with two tables movies and actors to get 
-- the movie name and number of actors working in each movie. 

SELECT m.movie_name, COUNT(a.actor_id) AS number_of_actors
FROM  tblmovies m
LEFT  OUTER JOIN  tblactors a ON m.movie_id = a.movie_id
GROUP BY m.movie_id, m.movie_name;




-- 26.Write a query to display actor id, actors name (first_name, last_name)  
-- and movie name to match ALL records from the movies table with each 
-- record from the actors table.      


SELECT  a.actor_id,   a.first_name || ' ' || a.last_name AS actor_name, m.movie_name
FROM tblactors a
cross JOIN   tblmovies m;


select  m.movie_id,a.first_name || ' ' || a.last_name AS actor_name,m.movie_name
from tblmovies m inner  join tblactors a 
on m.movie_id= a.movie_id



select * from tblmovies
select * from tblactors 
select * from tbldirectors 


drop table tblmovies
drop table tblactors
drop table tbldirectors


















