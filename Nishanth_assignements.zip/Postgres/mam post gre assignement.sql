create TABLE departments 
(department_id NUMERIC PRIMARY KEY, 
department_name VARCHAR(20)); 


CREATE TABLE employees (
    employee_id NUMERIC PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(60) NOT NULL,
    email_id VARCHAR(70) UNIQUE,
    phonenumber VARCHAR(80),
    hire_date DATE DEFAULT CURRENT_DATE,
    job_id VARCHAR(90),
    salary NUMERIC CHECK (salary > 0),
    manager_id NUMERIC REFERENCES employees ON DELETE SET NULL ON UPDATE SET NULL,
    commission_pct NUMERIC(2, 2),
    department_id NUMERIC REFERENCES departments ON DELETE SET NULL ON UPDATE SET NULL
);


CREATE TABLE job_history (
    employee_id NUMERIC,
    start_date DATE,
    end_date DATE,
    job_id VARCHAR(60),
    department_id NUMERIC REFERENCES departments ON DELETE SET NULL ON UPDATE SET NULL,
    CONSTRAINT emp_date PRIMARY KEY (employee_id, start_date),
    CONSTRAINT empid_fk FOREIGN KEY (employee_id) REFERENCES employees ON DELETE SET NULL ON UPDATE SET NULL,
    CONSTRAINT job_hist_date CHECK (start_date < end_date)
);

INSERT INTO departments (department_id, department_name) VALUES
(1, 'HR'),
(2, 'IT'),
(3, 'Finance'),
(4, 'Marketing'),
(5, 'Sales'),
(6, 'Operations'),
(7, 'Research');


INSERT INTO employees (employee_id, first_name, last_name, email_id, phonenumber, job_id, salary, manager_id, commission_pct, department_id) VALUES
(101, 'John', 'cena', 'john.cena@example.com', '1234567890', 'Manager', 60000, NULL, 0.05, 1),
(102, 'steve', 'Smith', 'steve.smith@example.com', '9876543210', 'Developer', 50000, 101, 0.02, 2),
(103, 'Bob', 'odenkirk', 'bob.odenkirk@example.com', '7890123456', 'Analyst', 45000, 101, NULL, 3),
(104, 'kane', 'Williams', 'kane.williams@example.com', '5678901234', 'Manager', 62000, NULL, 0.03, 4),
(105, 'Charlie', 'cox', 'charlie.cox@example.com', '3456789012', 'Salesperson', 55000, 104, 0.01, 6),
(106, 'Eva', 'mendis', 'eva.mendis@example.com', '2345678901', 'Analyst', 48000, 104, NULL, 7),
(107, 'Ross', 'Taylor', 'Ross.taylor@example.com', '8765432109', 'Developer', 52000, 101, 0.02, 6),
(108, 'David', 'Miller', 'David.miller@example.com', '6789012345', 'Researcher', 47000, NULL, NULL, 5);


INSERT INTO job_history (employee_id, start_date, end_date, job_id, department_id) VALUES
(101, '2022-01-01', '2023-01-01', 'Manager', 1),
(102, '2022-02-15', '2023-02-15', 'Developer', 2),
(103, '2022-03-20', '2023-03-20', 'Analyst', 3),
(104, '2022-01-10', '2023-01-10', 'Manager', 4),
(105, '2022-04-05', '2023-04-05', 'Salesperson', 5),
(106, '2022-05-15', '2023-05-15', 'Analyst', 6),
(107, '2022-03-01', '2023-03-01', 'Developer', 2),
(108, '2022-06-01', '2023-06-01', 'Researcher', 7);



-- 1.Retrieve the information of all the employees working in the organization. 

SELECT * FROM EMPLOYEES


-- 2.fetch the specific details like employee_id, first_name, email_id and salary from the 
-- employees table. 

SELECT employee_id, first_name,email_id, salary
FROM EMPLOYEES

--3.Display the department numbers in which employees are present. If the 
--department_id is present more than once then, only one value should be retrieved. 

SELECT DISTINCT department_id
FROM employees;

--4. Display different job roles that are available in the company.  

SELECT DISTINCT job_id
FROM employees;

--5 Display the department data  in the ascending order and salary must be in 
--descending order. 
 
SELECT *
FROM employees
ORDER BY department_id ASC, salary DESC;

--6  retrieve the details of all the employees working in 10th department. 

SELECT *
FROM employees
WHERE department_id = 10;

--7 details of the employees working in 10th department along with the employee 
--details whose earning is more than 40000. 

SELECT *
FROM employees
WHERE department_id = 10 OR salary > 40000;


-- 8 display the last name and the job title of the employees who were not allocated to 
-- the manager. 

SELECT last_name, job_id
FROM employees
WHERE manager_id IS NULL;

-- 9.Generate a report for the employees whose salary ranges from 5000 to 12000 and 
-- they should either belongs to department 20 or department 50. Display the last name and 
-- the salary of the employee.  
-- Note: Rename the column name as Employee instead of lastname  and Monthly Salary 
-- instead of salary respectively. 

SELECT last_name AS Employee, salary AS "Monthly Salary"
FROM employees
WHERE (salary BETWEEN 5000 AND 12000) AND (department_id IN (20, 50));



-- 10. the employees details who had joined in the year 2003 
SELECT *
FROM employees
WHERE EXTRACT(YEAR FROM hire_date) = 2003;




-- 11.Write a query to display the last_name and number of  months for which the 
-- employee have worked rounding the months_worked column to its nearest whole number.   
-- Hint: No of months should be calculated from the date of joining of an employee to till date. 




SELECT
    last_name,
    EXTRACT(year FROM AGE(NOW(), hire_date)) * 12 +  
	EXTRACT(MONTH FROM AGE(NOW(), hire_date)) as months_worked
FROM employees;

-- 12.calculate their spending's designation-wise from each department.  


SELECT d.department_id,  d.department_name ,e.job_id,SUM(e.salary) AS total_spending
FROM departments d
inner JOIN employees e ON d.department_id = e.department_id
GROUP BY  d.department_id, d.department_name, e.job_id
ORDER BY d.department_id, e.job_id;


-- 13.calculate the following details of the employees using aggregate function in a 
-- department. 
-- ∙Employee with highest salary 
-- ∙Employee with lowest salary 
-- ∙Total salary of all the employees in the department  
-- ∙Average salary of the department 
-- Write a query to display the output  rounding the resultant values to its nearest whole 
-- number. 

SELECT department_id,MAX(salary) AS highest_salary, 
MIN(salary) AS lowest_salary,SUM(salary) AS total_salary,(AVG(salary)) AS average_salary
FROM employees
GROUP BY department_id;


-- 14.Modify the result obtained in the previous exercise to display the minimum, 
-- maximum, total and average salary for each job type. 

SELECT department_id,  job_id, MAX(salary) AS highest_salary,MIN(salary) AS lowest_salary,
SUM(salary) AS total_salary,(AVG(salary)) AS average_salary
FROM employees
GROUP BY department_id, job_id;


-- 15.fetch the details of the departments having less than 3 employees and are working in 
-- the department whose department_id is greater than 10.  

SELECT department_id, COUNT(employee_id) AS num_employees
FROM  employees
GROUP BY department_id
HAVING  COUNT(employee_id) < 3
    AND department_id > 10;
	
-- 16.fetch the manager_id and the minimum salary of the employee reporting to him. 
-- Arrange the result in descending order of the salaries excluding the details given below: 
-- ∙Exclude the employee whose manager is not mapped / not known. 
-- ∙Exclude the details if the minimum salary is less than or equal to 6000.

SELECT manager_id,MIN(salary) AS min_salary
FROM employees
WHERE  manager_id IS NOT NULL
GROUP BY  manager_id
HAVING MIN(salary) > 6000
ORDER BY min_salary DESC;


-- 17. details of the employees who have never changed their job role in the company. 


SELECT  e.employee_id, e.first_name,   e.last_name,  e.job_id
FROM  employees e
WHERE not EXISTS (
        SELECT  1  FROM  job_history j
        WHERE  j.employee_id = e.employee_id  AND j.job_id <> e.job_id
    );


-- 18 fetch the employee names and their departments in which they are working. 
SELECT  e.first_name,  e.last_name, d.department_name
FROM employees e
inner JOIN departments d ON e.department_id = d.department_id;



-- 19.retrieve all the department information with their corresponding employee names 
-- along with the newly added departments. 

SELECT d.department_id,  d.department_name,   e.first_name,   e.last_name
FROM departments d
LEFT JOIN   employees e ON d.department_id = e.department_id;


-- 20.details of the employee along with their managers. 
SELECT
    e.employee_id, e.first_name || ' ' || e.last_name AS employee_name,  
	e.job_id AS employee_job,e.salary AS employee_salary,
    m.employee_id AS manager_id,  m.first_name || ' ' || m.last_name AS manager_name
FROM   employees e
LEFT JOIN  employees m ON e.manager_id = m.employee_id;

-- 21. employee details who are reporting to the same manager as Maria reports to. 

SELECT e.employee_id, e.first_name || ' ' || e.last_name AS employee_name,  e.job_id AS employee_job,  e.salary AS employee_salary
FROM employees e
inner JOIN employees m ON e.manager_id = m.manager_id
WHERE m.first_name = 'Maria' or m.last_name= 'Maria'


-- 22.fetch the details of the employees working in the Executive department. 
SELECT  e.employee_id,  e.first_name || ' ' || e.last_name AS employee_name, e.job_id, e.salary,  d.department_name
FROM employees e
JOIN   departments d ON e.department_id = d.department_id
WHERE  d.department_name = 'Executive';


-- 23.fetch the details of employee whose salary is greater than the average salary of all 
-- the employees. 
SELECT  employee_id,  first_name || ' ' || last_name AS employee_name, job_id,  salary
FROM  employees
WHERE salary > (SELECT AVG(salary) FROM employees);


-- 24. Write a query which displays all Ellen's colleague's names. Label the name as "Ellen's 
-- colleague".  
-- Hint: If an employee is Ellen's colleague then their department_id will be same. 



SELECT first_name || ' ' || last_name AS "Ellens colleague"
FROM  employees
WHERE department_id = (SELECT department_id FROM employees WHERE first_name = 'Ellen');



-- 25.which employees from adminstration team is/are earning less than all the 
-- employees. 


SELECT employee_id,  first_name || ' ' || last_name AS employee_name,  salary
FROM  employees
WHERE  department_id = (SELECT department_id FROM departments WHERE department_name = 'Administration')
    AND salary <  all(SELECT salary FROM employees);


-- 26.  Write a query to display the last name and salary of those who reports to King. 

SELECT last_name,  salary
FROM employees
WHERE manager_id = (SELECT employee_id FROM employees WHERE last_name = 'King');


-- 27. Write a query to display the below requirement.   
-- Fetch employee id and first name of who work in a department with the employee's having 
-- ‘u’ in the  last_name.


SELECT  employee_id,  first_name
FROM employees
WHERE department_id IN (SELECT department_id FROM employees WHERE last_name LIKE '%u%');



-- 28.the employee who is getting highest pay in the specific department.


SELECT   employee_id,  first_name,  last_name,  salary
FROM   employees
WHERE (department_id, salary) IN (  SELECT department_id, MAX(salary) AS max_salary
									FROM employees
									WHERE department_id = 3
									GROUP BY department_id );
									
-- 29. the details of different employees who have atleast one person reporting to them. 

SELECT  e1.employee_id,  e1.first_name,   e1.last_name,  e1.job_id,   e1.salary,   e1.manager_id
FROM   employees e1
WHERE  EXISTS (
        SELECT 1  FROM employees e2
        WHERE e2.manager_id = e1.employee_id );
		

-- 30. the departments which was formed but it does not have employees working in 
-- them currently.  

SELECT d.department_id,  d.department_name
FROM  departments d
WHERE NOT EXISTS (
        SELECT 1 FROM employees e
        WHERE e.department_id = d.department_id );
 






select * from EMPLOYEES
select * from job_history
select * from departments













