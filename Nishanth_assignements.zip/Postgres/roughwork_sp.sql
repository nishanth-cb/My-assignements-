 CREATE TABLE tblProject 
( 
   ProjectId BIGINT PRIMARY KEY, 
   Name VARCHAR(100) NOT NULL, 
   Code VARCHAR(50) NOT NULL, 
   ExamYear SMALLINT NOT NULL 
); 
 
 
CREATE TABLE tblExamCentre  
( 
  ExamCentreId BIGINT PRIMARY KEY, 
  Code VARCHAR(100) NULL, 
  Name VARCHAR(100)  NULL 
); 
 
CREATE TABLE tblProjectExamCentre 
( 
   ProjectExamCentreId BIGINT PRIMARY KEY, 
   ExamCentreId BIGINT NOT NULL REFERENCES tblExamCentre(ExamCentreId), 
   ProjectId BIGINT REFERENCES tblProject(ProjectId) 
); 

INSERT INTO tblProject(ProjectId,Name,Code,ExamYear) VALUES 
(1,'8808-01-CW-YE-GCEA-2022','PJ0001',2022), 
(2,'6128-02-CW-YE-GCENT-2022','PJ0002',2022), 
(3, '7055-02-CW-YE-GCENA-2022','PJ0003',2022), 
(4,'8882-01-CW-YE-GCEA-2022','PJ0004',2022), 
(5,'7062-02-CW-YE-GCENT-2022','PJ0005',2022), 
(8,'6128-02-CW-YE-GCENT-1000','PJ0008',1000), 
(9,'7062-02-CW-YE-GCENT-5000','PJ0009',5000), 
(10,'8808-01-CW-YE-GCEA-2023','PJ0010',2023), 
(11,'8808-01-CW-YE-GCEA-2196','PJ0011',2196), 
(15,'6073-02-CW-YE-GCENA-2022','PJ0015',2022), 
(16,'8808-01-CW-YE-GCE0-2022','PJ0016',2022); 
 
 
 
INSERT INTO tblExamCentre(ExamCentreId,Name,Code) VALUES 
(112,'VICTORIA SCHOOL-GCENA-S','2711'), 
(185,'NORTHBROOKS SECONDARY SCHOOL-GCENA-S','2746'), 
(227,'YIO CHU KANG SECONDARY SCHOOL-GCENA-S','2721'), 
(302,'CATHOLIC JUNIOR COLLEGE','9066'), 
(303,'ANGLO-CHINESE JUNIOR COLLEGE','9067'), 
(304,'ST. ANDREW''S JUNIOR COLLEGE','9068'), 
(305,'NANYANG JUNIOR COLLEGE','9069'), 
(306,'HWA CHONG INSTITUTION','9070'), 
(1,NULL,'2011'), 
(2,'NORTHBROOKS SECONDARY SCHOOL-GCENA-S',NULL); 
 
 
INSERT INTO tblProjectExamCentre(ProjectExamCentreId,ProjectId,ExamCentreId) VALUES 
(44,1,112), 
(45,1,227), 
(46,1,185), 
(47,2,112), 
(48,2,227), 
(49,2,185), 
(50,3,112), 
(51,3,227), 
(52,3,185), 
(69,4,112); 

-- 1.Write a procedure to fetch the ProjectId, ProjectName, ProjectCode, ExamCentreName 
-- and ExamCentreCode from the tables tblProject and  
-- tblExamCentre based on the ProjectId and ExamCentreId passed as input parameters. 



CREATE OR REPLACE PROCEDURE sp_fetch (
    pId INT,
    eId INT
)
AS $$
DECLARE
    result_record RECORD;
BEGIN 
    SELECT p.projectid, p.name AS ProjectName, p.code AS ProjectCode, e.Name AS ExamCentreName, e.code AS ExamCentreCode
    INTO result_record
    FROM tblProject p
    INNER JOIN tblProjectExamCentre pe ON p.projectid = pe.projectid
    INNER JOIN tblExamCentre e ON pe.examcentreid = e.examcentreid
    WHERE p.projectid = pId AND e.examcentreid = eId;

    RAISE NOTICE 'Result: % % % % %', result_record.projectid, result_record.ProjectName, result_record.ProjectCode, result_record.ExamCentreName, result_record.ExamCentreCode;
END $$ LANGUAGE plpgsql;

CALL sp_fetch(3, 185);


-- 2.Write a procedure to insert values into the table tblProject when the data for the 
-- ProjectId  
-- which is being inserted does not exist in the table. 


CREATE OR REPLACE PROCEDURE sp_insert_project(
    pId INT,
    pName VARCHAR(255),
    pCode VARCHAR(255),
    pExamYear INT
)
AS $$
BEGIN
    -- Check if the ProjectId already exists
    IF NOT EXISTS (SELECT 1 FROM tblProject WHERE projectid = pId) THEN
        -- Insert the values into tblProject
        INSERT INTO tblProject(projectid, name, code, examyear)
        VALUES (pId, pName, pCode, pExamYear);

        -- Output a message indicating the successful insertion
        RAISE NOTICE 'Project with ProjectId % inserted successfully.', pId;
    ELSE
        -- Output a message indicating that the ProjectId already exists
        RAISE EXCEPTION 'Project with ProjectId % already exists.', pId;
    END IF;
END $$ LANGUAGE plpgsql;


CALL sp_insert_project(17, 'New Project', 'PJ0017', 2023);



select * from tblProject 
select * from tblExamCentre 
select * from tblProjectExamCentre 


 