CREATE TABLE department
(
   department_id INT PRIMARY KEY,
   department_name VARCHAR(100));

CREATE TABLE student
(
  student_id INT PRIMARY KEY,
  student_name VARCHAR(100),
  student_department INT  REFERENCES department(department_id),
  stipend INT);
  
INSERT INTO department(department_id,department_name) values 
(1,'Science'),
(2,'Commerce'),
(3,'Bio-Chemistry'),
(4,'Bio-Medical'),
(5,'Fine Arts'),
(6,'Literature'),
(7,'Animation'),
(8,'Marketing');



INSERT INTO student(student_id,student_name, student_department,stipend) values 
(1,'Hadria',7,2000),
(2,'Trumann',2,2000),
(3,'Earlie',3,2000),
(4,'Monika',4,2000),
(5,'Aila',5,2000),
(6,'Trina',5,2000),
(7,'Esteban',3,2000),
(8,'Camilla',1,2000),
(9,'Georgina',4,2000),
(10,'Reed',6,16000),
(11,'Northrup',7,2000),
(12,'Tina',2,2000),
(13,'Jonathan',	2,2000),
(14,'Renae',7,2000),
(15,'Sophi',6,16000),
(16,'Rayner',3,2000),
(17,'Mona',6,16000),
(18,'Aloin',5,2000),
(19,'Florance',5,2000),
(20,'Elsie',5,2000);


--stored procedures
-- 1.Write a stored procedure to insert values into the student table ans also update the 
-- student_department to 7 when the student_id
-- is between 400 and 700.

CREATE OR REPLACE PROCEDURE SP_insrtStudent(
    sid INT,
    sname VARCHAR(100),
    sdept INT,
    stipend INT 
)
AS $$
BEGIN

    INSERT INTO student(student_id, student_name, student_department, stipend)
    VALUES (sid, sname, sdept, stipend);

   
    IF sid BETWEEN 400 AND 700 THEN
        UPDATE student
        SET student_department = 7
        WHERE student_id = sid;
    END IF;
END;
$$ LANGUAGE plpgsql;


CALL SP_insrtStudent(402, 'John CENA', 6, 2000);
 select * from student

-- 2.Write a procedure to update the department name to 'Animation' when the department id is 7.
-- This command has to be committed.
-- Write another statement to delete the record from the students table based on the studentid passed as the
--  input parameter.This statement should not be committed.

CREATE PROCEDURE SP_updel(
dept_id INT ,
stu_id INT )
AS $$ 
BEGIN 
IF dept_id=7 THEN 
 UPDATE DEPARTMENT
 SET department_name='Animation'
 WHERE department_id=dept_id;
 COMMIT;
 END IF ;
 
 DELETE FROM STUDENT 
 WHERE student_id =stu_id;
END ;
$$ LANGUAGE plpgsql;

CALL SP_updel(7,7)



-- 3.Write a procedure to display the sum,average,minimum and maximum values of the column stipend
-- from the students table.

CREATE OR REPLACE PROCEDURE SP_stipened (
INOUT "sum1" INT =0,
INOUT "aver" INT =0,
INOUT "minI" INT =0,
INOUT "maxi" INT =0)


AS $$
BEGIN 
SELECT sum(stipend), avg(stipend),min(stipend),max(stipend)
into "sum1","aver","minI","maxi"
from  STUDENT;
END ;
$$ LANGUAGE plpgsql;

call SP_stipened(0,0,0,0)



-- 1.Fetch all the records from the table students where 
-- the stipend is more than 'Florence'
select * from student 
where stipend  > (select stipend from  student where student_name like 'Florance')



-- 2.Return all the records from the students table who 
-- get more than the minimum stipend for the department 'FineArts'.


SELECT *
FROM student 
WHERE stipend > (SELECT MIN(stipend) FROM student
				   WHERE student_department = (SELECT department_id FROM department 
											   WHERE department_name = 'Fine Arts'));
											   


-- 1.Using a subquery, list the name of the employees, paid more than 'Fred Costner' from employees.


select * from employees
where salary > (select salary from employees where first_name like 'John') 


-- 2.Find all employees who earn more than the average salary in their department.

select * from employees
where salary > (select avg(salary) from employees  ) 


-- 3.Write a query to select those employees who does not work in those department where
-- the managers of ID between 100 and 200 works.

SELECT * FROM employees
WHERE manager_id  not between 100 and 200


-- 4.Find employees who have at least one person reporting to them.

select * from employees 
where manager_id is not null


---------------------------------------------------------------------------------------------------------

--CTE

-- 1.Write a query to fetch the student_name,,stipend and department_name from the students and departments
-- table where the student_id is between 1 to 5 AND stipend is in the range of 2000 to 4000.

WITH stuquery AS (
SELECT S.student_name,S.stipend,D.department_name
FROM STUDENT S INNER JOIN DEPARTMENT D ON S.student_department = D.department_id
where S.student_id between 1 and 5 
	and S.stipend between 2000 and 4000 )
select * from stuquery;



-- 2.Write a query to fetch the sum value of the stipend from the students table based on the department_id
-- where the departments 'Animation' and 'Marketing' should not be included and the sum value should be less than 4000.



WITH stuquery2 AS (
    SELECT  SUM(stipend) AS sum_stipend,  student_department
    FROM student
    WHERE student_department NOT IN (  SELECT department_id   FROM department
            WHERE department_name IN ('Animation', 'Marketing') )
    GROUP BY student_department
    HAVING  SUM(stipend) < 4000
)
SELECT *
FROM stuquery2;


-- 3.Using the concept of multiple cte, fetch the maximum value, minimm value, average and 
-- sum of the stipend based on the department and return all the values.


WITH 
maxCTE as ( select max(stipend)as maxi,student_department
		  from student 
		  group by student_department),
minCTE as (select min(stipend) as mini,student_department
		  from student 
		  group by student_department )	,
avgCTE as (select  avg(stipend) as avgi,student_department
		  from student 
		  group by student_department  ),	  
sumCTE as (select  sum(stipend) as sumi ,student_department
		  from student 
		  group by student_department  )

select  m.student_department,m.maxi,min.mini,avg.avgi,sum.sumi from 	 maxCTE  m
inner join  minCTE min
on m.student_department= min.student_department
inner join  avgCTE avg
on min.student_department= avg.student_department
inner join  sumCTE sum
on avg.student_department= sum.student_department
order by m.student_department



SELECT * FROM STUDENT
SELECT * FROM DEPARTMENT
