﻿--aSSIGNEMENT 11 -- Create Users2 table
CREATE TABLE Users2 (
    UserId VARCHAR(50) PRIMARY KEY,
    UserName VARCHAR(50) NOT NULL,
    Password VARCHAR(50) NOT NULL,
    Age INT NOT NULL,
    Gender CHAR(1) CHECK (Gender IN ('M', 'F')),
    EmailId VARCHAR(50) UNIQUE,
    PhoneNumber NUMERIC(10) NOT NULL
);

-- Insert data into Users2 table
INSERT INTO Users2 (UserId, UserName, Password, Age, Gender, EmailId, PhoneNumber)
VALUES
    ('mary_potter', 'Mary Potter', 'Mary@123', 25, 'F', 'mary_p@gmail.com', 9786543211),
    ('jack_sparrow', 'Jack Sparrow', 'Spar78!jack', 28, 'M', 'jack_spa@yahoo.com', 7865432102),
    -- Extra rows
    ('harry_potter', 'Harry Potter', 'Harry@123', 26, 'M', 'harry_p@gmail.com', 9876543210),
    ('hermione_granger', 'Hermione Granger', 'Hermione@123', 24, 'F', 'hermione_g@gmail.com', 8765432109);

-- Create TheatreDetails1 table
CREATE TABLE TheatreDetails1 (
    TheatreId INT PRIMARY KEY IDENTITY(1, 1),
    TheatreName VARCHAR(50) NOT NULL,
    Location VARCHAR(50) NOT NULL
);

-- Insert data into TheatreDetails1 table
INSERT INTO TheatreDetails1 (TheatreName, Location)
VALUES
    ('PVR', 'Mysuru'),
    ('Inox', 'Bengaluru'),
    -- Extra row
    ('Cinepolis', 'Chennai');

-- Create ShowDetails table
CREATE TABLE ShowDetails1 (
    ShowId INT PRIMARY KEY IDENTITY(1001, 1),
    TheatreId INT FOREIGN KEY REFERENCES TheatreDetails1(TheatreId) NOT NULL,
    ShowDate DATE NOT NULL,
    ShowTime TIME NOT NULL,
    MovieName VARCHAR(50) NOT NULL,
    TicketCost DECIMAL(6, 2) NOT NULL,
    TicketsAvailable INT NOT NULL
);

-- Insert data into ShowDetails table
INSERT INTO ShowDetails1 (TheatreId, ShowDate, ShowTime, MovieName, TicketCost, TicketsAvailable)
VALUES
    (1, '2023-11-28', '14:30', 'Avengers', 250.00, 100),
    (2, '2023-11-26', '17:30', 'Hit Man', 200.00, 150),
    -- Extra row
    (3, '2023-12-01', '19:00', 'Spider-Man', 220.00, 120);

-- Create BookingDetails1 table
CREATE TABLE BookingDetails1 (
    BookingId VARCHAR(5) PRIMARY KEY,
    UserId VARCHAR(50) FOREIGN KEY REFERENCES Users2(UserId) NOT NULL,
    ShowId INT FOREIGN KEY REFERENCES ShowDetails1(ShowId) NOT NULL,
    NoOfTickets INT NOT NULL,
    TotalAmt DECIMAL(6, 2) NOT NULL
);

-- Insert data into BookingDetails1 table
INSERT INTO BookingDetails1 (BookingId, UserId, ShowId, NoOfTickets, TotalAmt)
VALUES
    ('B1001', 'jack_sparrow', 1001, 2, 500.00),
    ('B1002', 'mary_potter', 1002, 5, 1000.00),
    -- Extra rows
    ('B1003', 'harry_potter', 1001, 3, 750.00),
    ('B1004', 'hermione_granger', 1003, 4, 880.00);




--Stored Procedure: usp_BookTheTicket
--Create a stored procedure named usp_BookTheTicket to insert values into the BookingDetails table. Implement appropriate exception handling.
--Input Parameters:
--UserId
--ShowId
--NoOfTickets
--Functionality:
--Check if UserId is present in Users table
--Check if ShowId is present in ShowDetails table
--Check if NoOfTickets is a positive value and is less than or equal to TicketsAvailable value for the particular ShowId
--If all the validations are successful, insert the data by generating the BookingId and calculate the total amount based on the TicketCost
--Return Values:
--1, in case of successful insertion
---1,if UserId is invalid
---2,if ShowId is invalid
---3,if NoOfTickets is less than zero
---4,if NoOfTickets is greater than TicketsAvailable
---99,in case of any exception



CREATE OR ALTER PROCEDURE usp_BookTheTicket
    @UserId VARCHAR(50),
    @ShowId INT,
    @NoOfTickets INT,
    @Result INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    
    BEGIN TRY
        -- Check if UserId is present in Users table
        IF NOT EXISTS (SELECT 1 FROM Users2 WHERE UserId = @UserId)
        BEGIN
            SET @Result = -1;  -- UserId is invalid
            RETURN;
        END

        -- Check if ShowId is present in ShowDetails table
        IF NOT EXISTS (SELECT 1 FROM ShowDetails1 WHERE ShowId = @ShowId)
        BEGIN
            SET @Result = -2;  -- ShowId is invalid
            RETURN;
        END

        -- Check if NoOfTickets is a positive value
        IF @NoOfTickets < 0
        BEGIN
            SET @Result = -3;  -- NoOfTickets is less than zero
            RETURN;
        END

        -- Check if NoOfTickets is less than TicketsAvailable for the particular ShowId
        IF @NoOfTickets > (SELECT TicketsAvailable FROM ShowDetails1 WHERE ShowId = @ShowId)
        BEGIN
            SET @Result = -4;  -- NoOfTickets is greater than TicketsAvailable
            RETURN;
        END

        -- Insert the data into BookingDetails
        INSERT INTO BookingDetails1 (BookingId, UserId, ShowId, NoOfTickets, TotalAmt)
        VALUES (
            CONCAT('B', (SELECT ISNULL(MAX(CAST(SUBSTRING(BookingId, 2, LEN(BookingId)) AS INT)), 0) + 1 FROM BookingDetails1)),
            @UserId,
            @ShowId,
            @NoOfTickets,
            @NoOfTickets * (SELECT TicketCost FROM ShowDetails WHERE ShowId = @ShowId)
        );

        SET @Result = 1;  -- Successful insertion
    END TRY
    BEGIN CATCH
        SET @Result = -99;  -- Exception occurred
    END CATCH;
END;


DECLARE @ResultCode INT,
 @GIJH INT

EXEC usp_BookTheTicket
 'jack_sparrow',
 1001,
    2,
  @ResultCode OUTPUT;

PRINT @ResultCode;

--Function: ufn_GetMovieShowtimes
--Create a function ufn_GetMovieShowtimes to get the show details based on the MovieName and Location
--Input Parameter:
--MovieName
--Location
--Functionality:
--Fetch the details of the shows available for a given MovieName in a location


CREATE OR ALTER FUNCTION ufn_GetMovieShowtimes
(
    @MovieName VARCHAR(50),
    @Location VARCHAR(50)
)
RETURNS TABLE
AS
RETURN
(
    SELECT
        sd.MovieName,
        sd.ShowDate,
        sd.ShowTime,
        td.TheatreName,
        sd.TicketCost
    FROM
        ShowDetails sd
    INNER JOIN
        TheatreDetails1 td ON sd.TheatreId = td.TheatreId
    WHERE
        sd.MovieName = @MovieName
        AND td.Location = @Location
);

SELECT *
FROM ufn_GetMovieShowtimes('Avengers', 'Mysuru');




-- Function: ufn_BookedDetails
--Create a function ufn_BookedDetails to get the booking details based on the BookingId
--Input Parameter:
--⦁	BookingId
--Functionality:
--⦁	Fetch the details of the ticket purchased based on the BookingId
--Return Value:
--A table containing following fields:
--BookingId	UserName	MovieName	TheatreName	ShowDate	ShowTime	NoOfTickets	TotalAmt

CREATE OR ALTER FUNCTION ufn_BookedDetails
(
    @BookingId VARCHAR(5)
)
RETURNS TABLE
AS
RETURN
(
    SELECT
        bd.BookingId,
        u.UserName,
        sd.MovieName,
        td.TheatreName,
        sd.ShowDate,
        sd.ShowTime,
        bd.NoOfTickets,
        bd.TotalAmt
    FROM
        BookingDetails1 bd
    INNER JOIN
        Users2 u ON bd.UserId = u.UserId
    INNER JOIN
        ShowDetails sd ON bd.ShowId = sd.ShowId
    INNER JOIN
        TheatreDetails1 td ON sd.TheatreId = td.TheatreId
    WHERE
        bd.BookingId = @BookingId
);

SELECT *
FROM ufn_BookedDetails('B1001');
