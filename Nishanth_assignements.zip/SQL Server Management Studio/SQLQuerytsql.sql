--BEGIN TRY
--declare 
--@cid int=101,
--@lstock int=0,
--@tid varchar(5)='T1001',
--@quantity int =3

--declare 
--@cust varchar(4)= NULL,
--@txnid int= 1007
--select @lstock= stock
--from toys
--WHERE ToyId=@tid
--print @lstock

--IF @cId IS NULL OR @TId IS NULL
--    BEGIN
        
--        PRINT 'Customer or Toy does not exist';
--    END
--	Else 
--		begin 
--			IF @lStock IS NULL OR @lStock < 1
--			BEGIN
           
--            PRINT 'Insufficient stock for the selected toy';
--			END
--		EnD
--		 DECLARE @Stock INT;
        
--        SELECT @Stock = @lstock
--        FROM toys
      
		
--		UPDATE Toys
--            SET Stock= @Stock + @quantity
--            WHERE ToyId = @TId;

			
Select * from customer			

--END 
--TRY
--BEGIN CATCH
--    PRINT 'An error occurred: ' + ERROR_MESSAGE();
--END CATCH;


 --declare 
	--@cid1 int=101, 
	--@lstock int=0,
	--@toyID varchar(5)='T1001',
	--@quantity int =3999999

declare 
	@IsCus INT=-1;

SELECT
	@IsCus=[CustID]
FROM
	[Customer]
WHERE
	[custID] = @cid;

IF @IsCus=-1
BEGIN
	PRINT 'Invalid Customer'
	GOTO EOP
END

--TOY CONFIRMATION
declare 
	@IsToy VARCHAR='';

SELECT
	@IsToy=[ToyID]
FROM
	[Toys]
WHERE
	[ToyID] = @toyID;

IF @IsToy=''
BEGIN
	PRINT 'Invalid Toy'
	GOTO EOP
END

-- CHECK IF STOCK AVAILABLE
declare 
	@StockAvailable int;

SELECT
	@StockAvailable=[Stock]
FROM
	[Toys]
WHERE
	[ToyID] = @toyID;

IF @StockAvailable<@quantity
BEGIN
	PRINT 'OUT OF STOCK !!'
	GOTO EOP
END

-- START THE TRANSACTION
--	UPDATE THE STIOCKS as STOCK = STOCK - QUANTITY
--	ADD the TRANSACTION RECORD TO TRANSACTION TABLE

BEGIN TRANSACTION [UpdateRecords]
	BEGIN TRY
		UPDATE Toys
            SET Stock= @StockAvailable + @quantity
            WHERE ToyId = @toyID;
	END TRY	

		
	BEGIN CATCH
		ROLLBACK [UpdateRecords]
	END CATCH
COMMIT TRANSACTION [UpdateRecords]



EOP:
	PRINT 'Thank you for visiting'









select * from transactions
select * from toys






Declare @toyid varchar(20)
declare @cid varchar(20)
Declare @Quantity int
Declare @Stock int
Declare @txnid int=1015
Declare @custid int=102
Declare @txncost int 
Declare @price int =500

	set @toyid=(select toyid from toys where toyid='t1001')
	set @Quantity=5

	begin
		update toys
		set stock=stock-@Quantity
		where toyid='t1001'

--set txncost =price * quantity
		set @txncost=@price*@Quantity
		insert into transactions values(@txnid,@custid,@toyid,@Quantity,@txncost)
		
		set @Stock=(select stock from toys where toyid ='t1001')

		print concat('current stock is' ,@Stock)
		print 'toys table updated'
		select * from toys
		print 'transactions table got inserted'
		select * from transactions
		end



CREATE PROCEDURE uspex1 
AS 
BEGIN 
SELECT * FROM customer
SELECT * FROM tblEmployee
END




-- Customers table
create TABLE Customer2 (
    CustomerId INT PRIMARY KEY,
    CustomerName VARCHAR(100) NOT NULL,
    VendorName VARCHAR(100) NOT NULL
);

-- Products table
create TABLE Products (
    ProductId INT PRIMARY KEY,
    ProductName VARCHAR(100) NOT NULL,
    Category VARCHAR(50) NOT NULL,
    VendorName VARCHAR(100) NOT NULL
);

-- Sales table
create TABLE Sales (
    SaleId INT PRIMARY KEY,
    CustomerId INT REFERENCES Customer2(CustomerId),
    ProductId INT REFERENCES Products(ProductId),
    SaleDate DATE,
    SaleAmount DECIMAL(10, 2)
);


-- Insert data into Customers
INSERT INTO Customer2 VALUES
(1, 'Rahul', 'Vendor1'),
(2, 'Priya', 'Vendor2'),
(3, 'Sandeep', 'Vendor1'),
(4, 'Neha', 'Vendor3');

-- Insert data into Products
INSERT INTO Products VALUES
(101, 'Mobile', 'Electronics', 'Vendor1'),
(102, 'Laptop', 'Electronics', 'Vendor2'),
(103, 'Shirt', 'Apparel', 'Vendor3'),
(104, 'Groceries', 'Grocery', 'Vendor1');

-- Insert data into Sales
INSERT INTO Sales VALUES
(1001, 1, 101, '2023-01-01', 5000),
(1002, 2, 102, '2023-01-05', 8000),
(1003, 1, 103, '2023-01-10', 1000),
(1004, 3, 104, '2023-01-15', 2000),
(1005, 2, 101, '2023-01-20', 3000);

--1.	create a procedure to list the sales details of the products belonging to the 
--given vendor and for the given interval

CREATE OR ALTER PROCEDURE usp_ListSalesForVendorAndInterval
    @vendorName VARCHAR(100),
    @startDate DATE,
    @endDate DATE
AS
BEGIN
    SELECT
        c.CustomerName,
        p.ProductName,
        s.SaleDate,
        s.SaleAmount
    FROM
        Customer2 c
    JOIN
        Sales s ON c.CustomerId = s.CustomerId
    JOIN
        Products p ON s.ProductId = p.ProductId
    WHERE
        p.VendorName = @vendorName
        AND s.SaleDate BETWEEN @startDate AND @endDate;
END;

EXEC usp_ListSalesForVendorAndInterval 'Vendor1', '2023-01-01', '2023-01-15';



--2.	create a procedure to list the sales details of the produtcs belonging to the
--given vendor and for the given interval where in the total sales amount exceeds the 
--given value

CREATE OR ALTER PROCEDURE usp_ListSalesExceedingAmount
    @vendorName VARCHAR(100),
    @startDate DATE,
    @endDate DATE,
    @minAmount DECIMAL(10, 2)
AS
BEGIN
    SELECT
        c.CustomerName,
        p.ProductName,
        s.SaleDate,
        s.SaleAmount
    FROM
        Customer2 c
    JOIN
        Sales s ON c.CustomerId = s.CustomerId
    JOIN
        Products p ON s.ProductId = p.ProductId
    WHERE
        p.VendorName = @vendorName
        AND s.SaleDate BETWEEN @startDate AND @endDate
        AND s.SaleAmount > @minAmount;
END;


--3.	create a procedure to list the total no produts sold and the revenue earned 
--for�the given category of products within the specified interval

CREATE OR ALTER PROCEDURE usp_ListTotalProductsAndRevenue
    @category VARCHAR(50),
    @startDate DATE,
    @endDate DATE
AS
BEGIN
    SELECT
        p.Category,
        COUNT(s.ProductId) AS TotalProductsSold,
        SUM(s.SaleAmount) AS TotalRevenue
    FROM
        Products p
    LEFT JOIN
        Sales s ON p.ProductId = s.ProductId AND s.SaleDate BETWEEN @startDate AND @endDate
    WHERE
        p.Category = @category
    GROUP BY
        p.Category;
END;



EXEC usp_ListTotalProductsAndRevenue 'Electronics', '2023-01-01', '2023-01-20';





