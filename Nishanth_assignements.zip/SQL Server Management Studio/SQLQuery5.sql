SELECT NAME ,FILENAME FROM SYS.sysaltfiles

CREATE Database Payroll

use Payroll
create table tblEmploye
(EmployeID int,
EmployeName varchar(50),
Designation varchar(50),
JoinDate dateTime,
EmailId Varchar(50),
Salary money,
DepartmentId int)

INSERT INTO tblEmploye Values (1000, 'pavitra','TSE','10/23/2023','jvghjuhhj@jgfd.com','75454',30)
select * from tblEmploye;
INSERT INTO tblEmploye Values (1001, 'Bas de leed','TSE','10/23/2023','jvghjusdhhj@jgfd.com','756454',31)
INSERT INTO tblEmploye Values (1002, 'rachi9','DB','10/23/2023','jvghjvdcuhhj@jgfd.com','7567454',30)
INSERT INTO tblEmploye Values (1003, 'kendal','HR','10/23/2023','jvghjuhghhj@jgfd.com','4784',33)
INSERT INTO tblEmploye Values (1004, 'roman','TSE','10/23/2023','jvghjmruhhj@jgfd.com','754954',30)

INSERT INTO tblEmploye Values (1005, 'sagar','WWE','10/23/2023','jvghjmruhhj@jgfd.com','4748',32)
INSERT INTO tblEmploye Values (1006, 'water','PE','10/23/2023','water@jgfd.com','75678',31)
INSERT INTO tblEmploye Values (1007, 'jhoncena','CRIC','10/23/2023','jvghjmruhhj@jgfd.com','587678',30)
INSERT INTO tblEmploye Values (1008, 'reigns','Wat','10/23/2023','reigns@jgfd.com','53123',33)
INSERT INTO tblEmploye Values (1009, 'kevinowens','no','10/23/2023','kevinowens@jgfd.com','5657',32)

select EmployeName, EmployeID,DepartmentId from tblEmploye
select * from tblEmploye  where salary<20000 


create table tblDepartment
(DepartmentID Int PRIMARY KEY ,
DepartmentName Varchar(50) Not null ,
Location Varchar(50) not null)

insert into tblDepartment values (305,'HR','Newyork' )

insert into tblDepartment values (304,'IT','colombo' )
insert into tblDepartment values (307,'training','canberra' )
insert into tblDepartment values (308,'L& D','Aus' )
insert into tblDepartment values (309,'non tech','atlantic' )
insert into tblDepartment values (310,'sceince','indian' )
insert into tblDepartment values (34,'phy','pacific ' )
insert into tblDepartment values (374,'bio','tibert' )
insert into tblDepartment values (384,'mat','washi' )
insert into tblDepartment values (394,'sci','ohklamoa' )

Select * from tblDepartment

Select * from tblEmploye 
where DepartmentId =30
Group by DepartmentId
Having Salary > 20000

Select *  from tblEmploye 
where DepartmentId is null 

Select  EmployeName, Designation
where Designation='Business Analysts'


Select EmployeName, Designation, Salary from tblEmploye
Where DepartmentId =30
GROUP BY DepartmentId 
HAVING Salary between 200000 and 40000

Drop table tblEmploye