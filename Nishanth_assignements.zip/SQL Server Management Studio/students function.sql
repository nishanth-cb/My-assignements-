
create TABLE Departments (
    DepartmentId INT PRIMARY KEY,
    DepartmentName VARCHAR(50)
);

-- Insert data into Departments table
INSERT INTO Departments (DepartmentId, DepartmentName)
VALUES
    (1, 'CSE'),
    (2, 'ISE'),
    (3, 'ECE'),
	(4, 'Mechanical'),
    (5, 'Civil');
;

-- Create StudentMaster table
create TABLE StudentMaster (
    Id INT PRIMARY KEY,
    Name VARCHAR(50),
    DateOfJoin DATE,
    DepartmentId INT,
    FOREIGN KEY (DepartmentId) REFERENCES Departments(DepartmentId)
);

-- Insert data into StudentMaster table
INSERT INTO StudentMaster (Id, Name, DateOfJoin, DepartmentId)
VALUES
    (1, 'Ravi', '2022-01-05', 1),
    (2, 'Shanthala', '2021-07-03', 2),
    (3, 'Sunad', '2021-08-09', 3),
	 (4, 'Amit', '2022-02-15', 4),
    (5, 'Priya', '2021-09-20', 5);

-- Create Subjects table
create TABLE Subjects (
    SubId INT PRIMARY KEY,
    Subject VARCHAR(50)
);

-- Insert data into Subjects table
INSERT INTO Subjects (SubId, Subject)
VALUES
    (101, 'Web Design'),
    (102, 'C#.Net'),
    (103, 'RDBMS'),
	 (104, 'Mobile App Development'),
    (105, 'Data Structures');

-- Create DepartmentSubjects table
create TABLE DepartmentSubjects (
    SlNo INT PRIMARY KEY,
    DepartmentId INT,
    SubjectId INT,
    FOREIGN KEY (DepartmentId) REFERENCES Departments(DepartmentId),
    FOREIGN KEY (SubjectId) REFERENCES Subjects(SubId)
);

-- Insert data into DepartmentSubjects table
INSERT INTO DepartmentSubjects (SlNo, DepartmentId, SubjectId)
VALUES
    (1, 1, 101),
    (2, 2, 102),
    (3, 2, 101),
    (4, 4, 103),
	(5, 3, 105),
    (6, 1, 105),
    (7, 5, 105);

-- Create Marks table
CREATE TABLE Marks (
    StudentId INT,
    SubjectId INT,
    DoE DATE,
    Scores INT,
    PRIMARY KEY (StudentId, SubjectId),
    FOREIGN KEY (StudentId) REFERENCES StudentMaster(Id),
    FOREIGN KEY (SubjectId) REFERENCES Subjects(SubId)
);


INSERT INTO Marks (StudentId, SubjectId, DoE, Scores)
VALUES
    (1, 101, '2022-01-01', 72),
    (2, 102, '2022-03-10', 85),
    (3, 101, '2022-02-28', 90),
    (4, 103, '2022-02-28', 25),
    (5, 105, '2022-02-28', 50);


-- Create a table-valued function to list student details



--1.Each department has only five Subjects 
--2.Some subjects can be a common subject between the departments 
--3.Student can take test/assessment on the subjects as per his department 
--4.Student can attempt only once in each subject 
--5.The Pass marks is variable, a student must pass in all subjects  to Pass 
--6.Grades are based on the percentage of scores, those above 79% would be graded as distinction 
--Those with 60 and above percentage would be graded as first class and those who score above 
--50% are graded as second class, the remaining are classified as Just passed 
--Grades are awarded only to those who pass in all subjects 
 
--1, Create a function to List the details as shown below for the students of a given department and 
--given pass marks 
--Student ID, Name, Total Marks, Percentage, No of Subjects Passed, No of Subjects attempted ,Result, Grade 

CREATE OR ALTER FUNCTION  dbo.studentdetails(
@departmentId INT,
 @passmarks INT)
RETURNS TABLE 
AS RETURN
(SELECT DISTINCT sm.Id AS STUDENT_ID,
 sm.Name AS STUDENT_NAME,
SUM(distinct m.Scores) AS TOTAL_MARKS ,
 CAST(((SUM(distinct m.Scores) * 100.0/100) / COUNT(DISTINCT ds.SubjectId)) AS FLOAT) AS Percentage,
COUNT(DISTINCT  CASE WHEN m.Scores>=@passmarks THEN DS.SubjectId END ) AS noOfSubjectsPassed,
COUNT(DISTINCT DS.SubjectId) AS noOfSubjectsAttempted,
CASE WHEN COUNT(DISTINCT CASE WHEN m.Scores>= @passmarks THEN DS.SubjectId END )=COUNT(DISTINCT DS.SubjectId) THEN 'PASS' ELSE 'FAIL' END AS RESULT,
CASE
WHEN (m.Scores)>79 THEN 'DISTINCTION'
WHEN (m.Scores)>=60 THEN 'FIRST CLASS'
WHEN (m.Scores)>=50 THEN 'SECOND CLASS'
WHEN (m.Scores)<@passmarks THEN 'NA'
ELSE 'JUST PASSED'
END AS GRADES

FROM StudentMaster sm 
inner   JOIN Marks m ON sm.Id=m.StudentId
inner   JOIN DepartmentSubjects DS ON DS.DepartmentId=sm.DepartmentId
WHERE sm.DepartmentId= @departmentId
GROUP BY sm.Id,sm.Name, m.Scores
)
 
 select * from dbo.studentdetails(2,50)

SELECT * FROM Departments
SELECT * FROM StudentMaster
SELECT * FROM Subjects
SELECT * FROM DepartmentSubjects
SELECT * FROM Marks






















begin transaction 
-- Additional data for StudentMaster
INSERT INTO StudentMaster (Id, Name, DateOfJoin, DepartmentId)
VALUES
    (6, 'John', '2021-05-10', 5),
    (7, 'Alice', '2022-03-15', 5),
    (8, 'Bob', '2022-01-20', 4),
    (9, 'Eva', '2021-11-08', 3),
    (10, 'Michael', '2022-04-25', 2);

-- Additional data for Subjects
INSERT INTO Subjects (SubId, Subject)
VALUES
    (106, 'Operating Systems'),
    (107, 'Computer Networks'),
    (108, 'Software Engineering');

-- Additional data for DepartmentSubjects
INSERT INTO DepartmentSubjects (SlNo, DepartmentId, SubjectId)
VALUES
    (8, 4, 106),
    (9, 4, 107),
    (10, 5, 108),
    (11, 5, 107),
    (12, 5, 106);

-- Additional data for Marks
INSERT INTO Marks (StudentId, SubjectId, DoE, Scores)
VALUES
    (6, 106, '2022-05-01', 65),
    (6, 107, '2022-05-10', 75),
    (7, 108, '2022-04-28', 82),
    (8, 106, '2022-02-20', 40),
    (8, 107, '2022-02-28', 60),
    (9, 106, '2022-01-15', 80),
    (9, 107, '2022-02-01', 90),
    (10, 108, '2022-05-05', 78),
    (10, 107, '2022-05-15', 70);


 begin transaction 
 rollback













 -- Insert data into Marks table
INSERT INTO Marks (StudentId, SubjectId, DoE, Scores)
VALUES
    (1, 101, '2022-01-01', 72),
	 (2, 102, '2022-03-10', 85),
    (3, 101, '2022-02-28', 90),
	(4, 103, '2022-02-28', 25),
	(5, 105, '2022-02-28', 50);




	BEGIN TRANSACTION 
	INSERT INTO Marks (StudentId, SubjectId, DoE, Scores)
VALUES(5, 103, '2022-02-28', 72),
(1, 104, '2022-02-28', 32),
(3, 102, '2022-02-28', 68);

BEGIN TRANSACTION 
ROLLBACK