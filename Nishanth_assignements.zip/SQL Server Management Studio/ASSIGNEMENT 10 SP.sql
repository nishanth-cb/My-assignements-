﻿--assignement 10 

-- Create tblEmployeeDtls table
CREATE TABLE tblEmployeeDtls (
    EmployeeId INT PRIMARY KEY,
    EmployeeName VARCHAR(50),
    JoiningDate DATE,
    Salary DECIMAL(10, 2),
    Bonus DECIMAL(10, 2),
    TotalBonusForYear DECIMAL(10, 2)
);

-- Insert sample data into tblEmployeeDtls
INSERT INTO tblEmployeeDtls (EmployeeId, EmployeeName, JoiningDate, Salary)
VALUES
    (1, 'John Doe', '2010-01-01', 60000),
    (2, 'Jane Smith', '2015-05-15', 80000),
    (3, 'Bob Johnson', '2020-03-10', 50000),
    (4, 'Alice Brown', '2022-07-20', 70000);

-- Create stored procedure to calculate bonus and return total bonus for the year
CREATE OR ALTER PROCEDURE usp_CalculateBonus
    @GivenDate DATE,
    @TotalBonusForYear DECIMAL(10, 2) OUTPUT
AS
BEGIN
    BEGIN TRY
        -- Calculate bonus based on the given criteria and update tblEmployeeDtls
        UPDATE tblEmployeeDtls
        SET
            Bonus = 
                CASE
                    WHEN DATEDIFF(YEAR, JoiningDate, @GivenDate) > 10 THEN Salary
                    WHEN DATEDIFF(YEAR, JoiningDate, @GivenDate) BETWEEN 5 AND 10 THEN Salary * 0.5
                    ELSE 5000
                END,
            TotalBonusForYear = ISNULL(TotalBonusForYear, 0) + 
                CASE
                    WHEN DATEDIFF(YEAR, JoiningDate, @GivenDate) > 10 THEN Salary
                    WHEN DATEDIFF(YEAR, JoiningDate, @GivenDate) BETWEEN 5 AND 10 THEN Salary * 0.5
                    ELSE 5000
                END;

        PRINT 'Bonus calculated and updated in tblEmployeeDtls.';

        -- Retrieve total bonus for the year
        SELECT @TotalBonusForYear = ISNULL(SUM(Bonus), 0)
        FROM tblEmployeeDtls;

        PRINT 'Total bonus for the year: ' + CAST(@TotalBonusForYear AS VARCHAR(20));
    END TRY
    BEGIN CATCH
        -- Handle exceptions
        PRINT 'Error: ' + ERROR_MESSAGE();
    END CATCH
END;

DECLARE @GivenDate DATE = '2023-01-01';
DECLARE @TotalBonus DECIMAL(10, 2);

EXEC usp_CalculateBonus @GivenDate = @GivenDate, @TotalBonusForYear = @TotalBonus OUTPUT;

--1.	Create a stored procedure that returns a sales report for a given
--time period for a given Sales Person. Write commands to invoke the procedure

-- Create tblSales table
CREATE TABLE tblSales (
    SalesId INT PRIMARY KEY,
    ProductName VARCHAR(50),
    SalesPerson VARCHAR(50),
    SaleDate DATE,
    SaleAmount DECIMAL(10, 2)
);

-- Insert sample data into tblSales
INSERT INTO tblSales (SalesId, ProductName, SalesPerson, SaleDate, SaleAmount)
VALUES
    (1, 'Product A', 'John Doe', '2023-01-15', 5000),
    (2, 'Product B', 'Jane Smith', '2023-01-20', 8000),
    (3, 'Product C', 'John Doe', '2023-02-05', 6000),
    (4, 'Product A', 'Alice Brown', '2023-02-10', 7500),
    (5, 'Product B', 'Jane Smith', '2023-03-01', 9000),
    (6, 'Product C', 'Alice Brown', '2023-03-15', 7000);

-- Create stored procedure to generate sales report
CREATE OR ALTER PROCEDURE usp_GetSalesReport
    @SalesPerson VARCHAR(50),
    @StartDate DATE,
    @EndDate DATE
AS
BEGIN
    BEGIN TRY
        -- Fetch sales report for the given time period and salesperson
        SELECT
            SalesId,
            ProductName,
            SaleDate,
            SaleAmount
        FROM
            tblSales
        WHERE
            SalesPerson = @SalesPerson
            AND SaleDate BETWEEN @StartDate AND @EndDate;

        PRINT 'Sales report generated successfully.';
    END TRY
    BEGIN CATCH
        -- Handle exceptions
        PRINT 'Error: ' + ERROR_MESSAGE();
    END CATCH
END;


-- Invoke the stored procedure with desired parameters
DECLARE @SalesPersonToReport VARCHAR(50) = 'Jane Smith';
DECLARE @StartDateToReport DATE = '2023-01-01';
DECLARE @EndDateToReport DATE = '2023-02-28';

EXEC usp_GetSalesReport @SalesPerson = @SalesPersonToReport, @StartDate = @StartDateToReport, @EndDate = @EndDateToReport;


--1.	Consider Toy Centre database
--Procedure Name : usp_UpdatePrice
--Description:    This procedure is used to update the price of a given product.
--Input Parameters:
--⦁	ProductId
--⦁	Price
--Output Parameter
--    UpdatedPrice
--Functionality:
--⦁	Check if the product id is valid, i.e., it exists in the Products table
--⦁	If all the validations are successful, update the price in the table Products appropriately
--⦁	Set the output parameter to the updated price
--⦁	If the update is not successful or in case of exception, undo the entire operation and set the output parameter to 0
--Return Values:
--⦁	1 in case of successful update
--⦁	-1 in case of any errors or exception

-- Create Products table
CREATE TABLE TBLProducts (
    ProductId INT PRIMARY KEY,
    ProductName VARCHAR(50),
    Price DECIMAL(10, 2)
);

-- Insert sample data into Products table
INSERT INTO TBLProducts (ProductId, ProductName, Price)
VALUES
    (1, 'Toy A', 20.00),
    (2, 'Toy B', 30.00),
    (3, 'Toy C', 25.50),
    (4, 'Toy D', 15.75);

-- Create usp_UpdatePrice stored procedure
CREATE OR ALTER PROCEDURE usp_UpdatePrice
    @ProductId INT,
    @Price DECIMAL(10, 2),
    @UpdatedPrice DECIMAL(10, 2) OUTPUT
AS
BEGIN
    DECLARE @TransactionSuccessful BIT = 1;

    BEGIN TRY
        -- Check if the product id is valid
        IF NOT EXISTS (SELECT 1 FROM TBLProducts WHERE ProductId = @ProductId)
        BEGIN
            PRINT 'Error: Invalid ProductId';
            SET @TransactionSuccessful = 0;
        END
        ELSE
        BEGIN
            -- Begin the transaction
            BEGIN TRANSACTION;

            -- Update the price in the Products table
            UPDATE TBLProducts
            SET Price = @Price
            WHERE ProductId = @ProductId;

            -- Set the output parameter to the updated price
            SET @UpdatedPrice = @Price;

            -- Commit the transaction
            COMMIT TRANSACTION;

            PRINT 'Update successful. Updated Price: ' + CAST(@UpdatedPrice AS VARCHAR(20));
        END
    END TRY
    BEGIN CATCH
        -- Handle exceptions
        PRINT 'Error: ' + ERROR_MESSAGE();
        SET @TransactionSuccessful = 0;

        -- Rollback the transaction in case of an exception
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
    END CATCH

    -- Return values
    IF @TransactionSuccessful = 1
        RETURN 1; -- Successful update
    ELSE
        RETURN -1; -- Error or exception
END;


DECLARE @ProductIdToUpdate INT = 2;
DECLARE @NewPrice DECIMAL(10, 2) = 35.00;
DECLARE @UpdatedPrice DECIMAL(10, 2);

EXEC usp_UpdatePrice @ProductId = @ProductIdToUpdate, @Price = @NewPrice, @UpdatedPrice = @UpdatedPrice OUTPUT;





--1.	Procedure Name : usp_InsertPurchaseDetails
--Description:

-- Create Users table
CREATE TABLE TBLUsers (
    EmailId VARCHAR(50) PRIMARY KEY,
    UserName VARCHAR(50)
);

-- Insert sample data into Users table
INSERT INTO TBLUsers (EmailId, UserName)
VALUES
    ('user1@example.com', 'User1'),
    ('user2@example.com', 'User2'),
    ('user3@example.com', 'User3');

-- Create Products table
CREATE TABLE Products1 (
    ProductId INT PRIMARY KEY,
    ProductName VARCHAR(50),
    AvailableQuantity INT
);

-- Insert sample data into Products table
INSERT INTO Products1 (ProductId, ProductName, AvailableQuantity)
VALUES
    (1, 'Product A', 100),
    (2, 'Product B', 50),
    (3, 'Product C', 75);

-- Create PurchaseDetails table
CREATE TABLE TBLPurchaseDetails (
    PurchaseId INT PRIMARY KEY,
    EmailId VARCHAR(50),
    ProductId INT,
    QuantityPurchased INT,
    PurchaseDate DATE
);

-- Create usp_InsertPurchaseDetails stored procedure
CREATE OR ALTER PROCEDURE usp_InsertPurchaseDetails
    @EmailId VARCHAR(50),
    @ProductId INT,
    @QuantityPurchased INT,
    @PurchaseId INT OUTPUT
AS
BEGIN
    DECLARE @TransactionSuccessful BIT = 1;

    BEGIN TRY
        -- Validate input parameters
        IF @EmailId IS NULL
        BEGIN
            PRINT 'Error: EmailId is null';
            SET @TransactionSuccessful = 0;
            RETURN -1; -- -1 if EmailId is null
        END

        IF NOT EXISTS (SELECT 1 FROM TBLUsers WHERE EmailId = @EmailId)
        BEGIN
            PRINT 'Error: EmailId is not valid';
            SET @TransactionSuccessful = 0;
            RETURN -2; -- -2 if EmailId is not valid
        END

        IF @ProductId IS NULL
        BEGIN
            PRINT 'Error: ProductId is null';
            SET @TransactionSuccessful = 0;
            RETURN -3; -- -3 if ProductId is null
        END

        IF NOT EXISTS (SELECT 1 FROM Products1 WHERE ProductId = @ProductId)
        BEGIN
            PRINT 'Error: ProductId is not valid';
            SET @TransactionSuccessful = 0;
            RETURN -4; -- -4 if ProductId is not valid
        END

        IF @QuantityPurchased IS NULL OR @QuantityPurchased <= 0
        BEGIN
            PRINT 'Error: QuantityPurchased is not valid or null';
            SET @TransactionSuccessful = 0;
            RETURN -5; -- -5 if QuantityPurchased is not valid or null
        END

        -- Begin the transaction
        BEGIN TRANSACTION;

        -- Insert purchase details into PurchaseDetails table
        INSERT INTO PurchaseDetails (EmailId, ProductId, QuantityPurchased)
        VALUES (@EmailId, @ProductId, @QuantityPurchased);

        -- Update available quantity in Products table
        UPDATE Products1
        SET AvailableQuantity = AvailableQuantity - @QuantityPurchased
        WHERE ProductId = @ProductId;

        -- Set the output parameter to the newly generated PurchaseId
        SET @PurchaseId = SCOPE_IDENTITY();

        -- Commit the transaction
        COMMIT TRANSACTION;

        PRINT 'Insertion and update successful. PurchaseId: ' + CAST(@PurchaseId AS VARCHAR(20));
    END TRY
    BEGIN CATCH
        -- Handle exceptions
        PRINT 'Error: ' + ERROR_MESSAGE();
        SET @TransactionSuccessful = 0;

        -- Rollback the transaction in case of an exception
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
        
        RETURN -99; -- -99 if there is any exception
    END CATCH

    -- Return values
    IF @TransactionSuccessful = 1
        RETURN 1; -- 1 in case of successful insertion and update
    ELSE
        RETURN -99; -- -99 if there is any exception
END;



DECLARE @EmailIdToInsert VARCHAR(50) = 'user1@example.com';
DECLARE @ProductIdToInsert INT = 1;
DECLARE @QuantityToPurchase INT = 5;
DECLARE @InsertedPurchaseId INT;

EXEC usp_InsertPurchaseDetails @EmailId = @EmailIdToInsert, @ProductId = @ProductIdToInsert, @QuantityPurchased = @QuantityToPurchase, @PurchaseId = @InsertedPurchaseId OUTPUT;



--1.	create a procedure to list the sales details of the products belonging 
--to the given vendor and for the given interval

-- Create tables for demonstration purposes
CREATE TABLE Vendors (
    VendorId INT PRIMARY KEY,
    VendorName VARCHAR(50)
);

CREATE TABLE Products (
    ProductId INT PRIMARY KEY,
    ProductName VARCHAR(50),
    VendorId INT FOREIGN KEY REFERENCES Vendors(VendorId)
);

CREATE TABLE Sales (
    SaleId INT PRIMARY KEY,
    ProductId INT FOREIGN KEY REFERENCES Products(ProductId),
    SaleDate DATE,
    SaleAmount DECIMAL(10, 2)
);

-- Insert sample data into tables
INSERT INTO Vendors (VendorId, VendorName) VALUES
    (1, 'Vendor A'),
    (2, 'Vendor B');

INSERT INTO Products (ProductId, ProductName, VendorId) VALUES
    (101, 'Product X', 1),
    (102, 'Product Y', 2),
    (103, 'Product Z', 1);

INSERT INTO Sales (SaleId, ProductId, SaleDate, SaleAmount) VALUES
    (1001, 101, '2023-01-15', 5000),
    (1002, 102, '2023-02-10', 8000),
    (1003, 101, '2023-02-15', 6000),
    (1004, 103, '2023-03-01', 7500),
    (1005, 102, '2023-03-20', 9000);

-- Create the stored procedure
CREATE OR ALTER PROCEDURE usp_ListSalesDetails
    @VendorName VARCHAR(50),
    @StartDate DATE,
    @EndDate DATE
AS
BEGIN
    -- Check if the provided vendor name is valid
    IF NOT EXISTS (SELECT 1 FROM Vendors WHERE VendorName = @VendorName)
    BEGIN
        PRINT 'Error: Invalid VendorName';
        RETURN;
    END

    -- List sales details for the specified vendor and interval
    SELECT
        S.SaleId,
        P.ProductName,
        V.VendorName,
        S.SaleDate,
        S.SaleAmount
    FROM
        Sales S
        INNER JOIN Products P ON S.ProductId = P.ProductId
        INNER JOIN Vendors V ON P.VendorId = V.VendorId
    WHERE
        V.VendorName = @VendorName
        AND S.SaleDate BETWEEN @StartDate AND @EndDate;
END;


DECLARE @VendorNameToSearch VARCHAR(50) = 'Vendor A';
DECLARE @StartDateToSearch DATE = '2023-01-01';
DECLARE @EndDateToSearch DATE = '2023-02-28';

EXEC usp_ListSalesDetails @VendorName = @VendorNameToSearch, @StartDate = @StartDateToSearch, @EndDate = @EndDateToSearch;



--2.	create a procedure to list the sales details of the 
--produtcs belonging to the given vendor and for the given interval where
--in the total sales amount exceeds the given value

-- Create the stored procedure
CREATE OR ALTER PROCEDURE usp_ListSalesDetailsWithThreshold
    @VendorName VARCHAR(50),
    @StartDate DATE,
    @EndDate DATE,
    @ThresholdAmount DECIMAL(10, 2)
AS
BEGIN
    -- Check if the provided vendor name is valid
    IF NOT EXISTS (SELECT 1 FROM Vendors WHERE VendorName = @VendorName)
    BEGIN
        PRINT 'Error: Invalid VendorName';
        RETURN;
    END

    -- List sales details for the specified vendor and interval with total sales exceeding the threshold
    SELECT
        P.ProductName,
        V.VendorName,
        SUM(S.SaleAmount) AS TotalSalesAmount
    FROM
        Sales S
        INNER JOIN Products P ON S.ProductId = P.ProductId
        INNER JOIN Vendors V ON P.VendorId = V.VendorId
    WHERE
        V.VendorName = @VendorName
        AND S.SaleDate BETWEEN @StartDate AND @EndDate
    GROUP BY
        P.ProductName, V.VendorName
    HAVING
        SUM(S.SaleAmount) > @ThresholdAmount;
END;


DECLARE @VendorNameToSearch VARCHAR(50) = 'Vendor A';
DECLARE @StartDateToSearch DATE = '2023-01-01';
DECLARE @EndDateToSearch DATE = '2023-02-28';
DECLARE @ThresholdAmount DECIMAL(10, 2) = 10000;

EXEC usp_ListSalesDetailsWithThreshold @VendorName = @VendorNameToSearch, @StartDate = @StartDateToSearch, @EndDate = @EndDateToSearch, @ThresholdAmount = @ThresholdAmount;


--3.	create a procedure to list the total no produts sold and the
--revenue earned for the given category of products within the specified interval



-- Create the stored procedure
CREATE OR ALTER PROCEDURE usp_ListCategorySalesAndRevenue
    @CategoryName VARCHAR(50),
    @StartDate DATE,
    @EndDate DATE
AS
BEGIN
    -- Check if the provided category name is valid
    IF NOT EXISTS (SELECT 1 FROM Categories WHERE CategoryName = @CategoryName)
    BEGIN
        PRINT 'Error: Invalid CategoryName';
        RETURN;
    END

    -- List total number of products sold and revenue earned for the specified category and interval
    SELECT
        C.CategoryName,
        COUNT(S.SaleId) AS TotalProductsSold,
        SUM(S.SaleAmount) AS TotalRevenue
    FROM
        Sales S
        INNER JOIN Products P ON S.ProductId = P.ProductId
        INNER JOIN Categories C ON P.CategoryId = C.CategoryId
    WHERE
        C.CategoryName = @CategoryName
        AND S.SaleDate BETWEEN @StartDate AND @EndDate
    GROUP BY
        C.CategoryName;
END;

DECLARE @CategoryNameToSearch VARCHAR(50) = 'Electronics';
DECLARE @StartDateToSearch DATE = '2023-01-01';
DECLARE @EndDateToSearch DATE = '2023-02-28';

EXEC usp_ListCategorySalesAndRevenue @CategoryName = @CategoryNameToSearch, @StartDate = @StartDateToSearch, @EndDate = @EndDateToSearch;


--1.	Write a Trigger to restrict operations on Employee table

CREATE OR ALTER TRIGGER tr_RestrictEmployeeOperations
ON Employee
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    -- Check if the total salary is within the allowed limit
    IF (SELECT SUM(Salary) FROM INSERTED) > 100000
    BEGIN
        THROW 50000, 'Total salary exceeds the allowed limit. Operation is restricted.', 1;
        ROLLBACK;
    END

    -- Additional conditions can be added as needed
    
END;

--2.	Write a Trigger to Alert the user whenever there is an update in tblEmployeedtls 
--table

CREATE OR ALTER TRIGGER tr_AlertOnEmployeeUpdate
ON tblEmployeedtls
AFTER UPDATE
AS
BEGIN
    -- Check if there are any updates
    IF UPDATE(EmployeeName) OR UPDATE(Salary)  -- Add other columns as needed
    BEGIN
        -- Your alert mechanism goes here.
        -- For example, you can use PRINT to display a message in the console.
        PRINT 'Alert: Employee details have been updated!';
    END
END;
