--	Store procedure assignement 9 
--Assignment Questions
create TABLE tblProject
(
   ProjectId BIGINT PRIMARY KEY,
   Name VARCHAR(100) NOT NULL,
   Code NVARCHAR(50) NOT NULL,
   ExamYear SMALLINT NOT NULL
);


create TABLE tblExamCentre 
(
  ExamCentreId BIGINT PRIMARY KEY,
  Code VARCHAR(100) NULL,
  Name VARCHAR(100)  NULL
);

create TABLE tblProjectExamCentre
(
   ProjectExamCentreId BIGINT PRIMARY KEY,
   ExamCentreId BIGINT NOT NULL FOREIGN KEY REFERENCES tblExamCentre(ExamCentreId),
   ProjectId BIGINT FOREIGN KEY REFERENCES tblProject(ProjectId)
);





INSERT INTO tblProject(ProjectId,Name,Code,ExamYear) VALUES
(1,	'8808-01-CW-YE-GCEA-2022',	'PJ0001',	2022),
(2,	'6128-02-CW-YE-GCENT-2022',	'PJ0002',	2022),
(3, '7055-02-CW-YE-GCENA-2022','PJ0003',	2022),
(4,	'8882-01-CW-YE-GCEA-2022','	PJ0004',	2022),
(5,'7062-02-CW-YE-GCENT-2022',	'PJ0005',	2022),
(8,	'6128-02-CW-YE-GCENT-1000',	'PJ0008',	1000),
(9,	'7062-02-CW-YE-GCENT-5000',	'PJ0009',	5000),
(10,'8808-01-CW-YE-GCEA-2023',	'PJ0010',	2023),
(11,'8808-01-CW-YE-GCEA-2196',	'PJ0011',	2196),
(15,'6073-02-CW-YE-GCENA-2022',	'PJ0015',	2022),
(16,'8808-01-CW-YE-GCE0-2022',	'PJ0016',	2022);


INSERT INTO tblExamCentre(ExamCentreId,Name,Code) VALUES
(112,'VICTORIA SCHOOL-GCENA-S','2711'),
(185,'NORTHBROOKS SECONDARY SCHOOL-GCENA-S','2746'),
(227,'YIO CHU KANG SECONDARY SCHOOL-GCENA-S','2721'),
(302,'CATHOLIC JUNIOR COLLEGE','9066'),
(303,'ANGLO-CHINESE JUNIOR COLLEGE','9067'),
(304,'ST. ANDREW''S JUNIOR COLLEGE','9068'),
(305,'NANYANG JUNIOR COLLEGE','9069'),
(306,'HWA CHONG INSTITUTION','9070'),
(1,NULL,'2011'),
(2,'NORTHBROOKS SECONDARY SCHOOL-GCENA-S',NULL);


INSERT INTO tblProjectExamCentre(ProjectExamCentreId,ProjectId,ExamCentreId) VALUES
(44,1,112),
(45,1,227),
(46,1,185),
(47,2,112),
(48,2,227),
(49,2,185),
(50,3,112),
(51,3,227),
(52,3,185),
(69,4,112);



--1.Write a procedure to fetch the ProjectId, ProjectName, ProjectCode, ExamCentreName 
--and ExamCentreCode from the tables tblProject and 
--tblExamCentre based on the ProjectId and ExamCentreId passed as input parameters.


CREATE OR ALTER PROCEDURE usp_FetchProjectAndExamCentreInfo
    @ProjectId INT,
    @ExamCentreId INT
AS
BEGIN
    SELECT
        p.ProjectId,
        p.Name AS ProjectName,
        p.Code AS ProjectCode,
        ec.Name AS ExamCentreName,
        ec.Code AS ExamCentreCode
    FROM
        tblProject p
    JOIN
        tblProjectExamCentre pec ON p.ProjectId = pec.ProjectId
    JOIN
        tblExamCentre ec ON pec.ExamCentreId = ec.ExamCentreId
    WHERE
        p.ProjectId = @ProjectId
        AND ec.ExamCentreId = @ExamCentreId;
END;

declare @ProjectId int , @ExamCentreId int 
EXEC usp_FetchProjectAndExamCentreInfo @ProjectId = 1, @ExamCentreId = 112;





--2.Write a procedure to insert values into the table tblProject when the 
--data for the ProjectId 
--which is being inserted does not exist in the table.


CREATE OR ALTER PROCEDURE usp_InsertIntoProject
    @ProjectId INT,
    @ProjectName NVARCHAR(255),
    @ProjectCode NVARCHAR(255),
    @ExamYear INT
AS
BEGIN
    BEGIN TRY
        -- Check if ProjectId already exists
        IF NOT EXISTS (SELECT 1 FROM tblProject WHERE ProjectId = @ProjectId)
        BEGIN
            -- Insert values into tblProject
            INSERT INTO tblProject (ProjectId, Name, Code, ExamYear)
            VALUES (@ProjectId, @ProjectName, @ProjectCode, @ExamYear);

            PRINT 'Insertion successful.';
        END
        ELSE
        BEGIN
            RAISEERROR('ProjectId already exists. Insertion aborted.', 16, 1);
        END
    END TRY
    BEGIN CATCH
        -- Handle exceptions
        PRINT 'Error: ' + ERROR_MESSAGE();
    END CATCH
END;

declare @ProjectId int ,@ProjectName varchar(50),@ProjectCode varchar(50),@ExamYear int 
EXEC usp_InsertProjectIfNotExists @ProjectId = 17, @ProjectName = 'New Project', @ProjectCode = 'PJ0017', @ExamYear = 2023;


--3.Write a procedure to update the columns-Code and Name in tblExamCentre 
--when either of the Code or the Name column is NULL 
--and also delete the records from the table tblProjectExamCentre when ProjectId IS 4.

CREATE OR ALTER PROCEDURE usp_UpdateExamCentreAndDeleteProjectExamCentre
AS
BEGIN
    BEGIN TRY
        -- Update tblExamCentre
        UPDATE tblExamCentre
        SET Code = ISNULL(Code, 'DefaultValueForCode'),
            Name = ISNULL(Name, 'DefaultValueForName')
        WHERE Code IS NULL OR Name IS NULL;

        PRINT 'Update successful for tblExamCentre.';

        -- Delete records from tblProjectExamCentre
        DELETE FROM tblProjectExamCentre
        WHERE ProjectId = 4;

        PRINT 'Deletion successful from tblProjectExamCentre.';
    END TRY
    BEGIN CATCH
        -- Handle exceptions
        PRINT 'Error: ' + ERROR_MESSAGE();
    END CATCH
END;

EXEC usp_UpdateExamCentreAndDeleteProjectExamCentre;

--4.Write a procedure to fetch the total count of records present in the table 
--tblProject based on the ProjectId AS OUTPUT parameter
--and also sort the records in ascending order based on the ProjectName

CREATE OR ALTER PROCEDURE usp_FetchProjectCountAndSort
    @ProjectId INT OUTPUT
AS
BEGIN
    BEGIN TRY
        -- Fetch total count of records based on ProjectId
        SELECT @ProjectId = COUNT(*) FROM tblProject;

        -- Sort records in ascending order based on ProjectName
        SELECT
            ProjectId,
            Name AS ProjectName,
            Code AS ProjectCode,
            ExamYear
        FROM
            tblProject
        ORDER BY
            ProjectName;

        PRINT 'Fetch and sort successful.';
    END TRY
    BEGIN CATCH
        -- Handle exceptions
        PRINT 'Error: ' + ERROR_MESSAGE();
    END CATCH
END;



--5.Write a procedure to create a Temp table named Students with columns- 
--StudentId,StudentName and Marks where the 
--column StudentId is generated automatically 
--and insert data into the table and also retrieve the data

CREATE OR ALTER PROCEDURE usp_CreateAndRetrieveStudentsTable
AS
BEGIN
    BEGIN TRY
        -- Create temporary table Students
        CREATE TABLE #Students
        (
            StudentId INT IDENTITY(1,1),
            StudentName NVARCHAR(255),
            Marks INT
        );

        PRINT 'Temporary table Students created.';

        -- Insert data into the temporary table
        INSERT INTO #Students (StudentName, Marks)
        VALUES ('John Doe', 85),
               ('Jane Smith', 92),
               ('Bob Johnson', 78);

        PRINT 'Data inserted into the temporary table.';

        -- Retrieve data from the temporary table
        SELECT * FROM #Students;

        PRINT 'Data retrieved from the temporary table.';
    END TRY
    BEGIN CATCH
        -- Handle exceptions
        PRINT 'Error: ' + ERROR_MESSAGE();
    END CATCH
END;

EXEC usp_CreateAndRetrieveStudentsTable;


--6.Write a procedure to perform the following DML operations on the column - ProjectName in tblProject table by using a varibale. 
--Declare a local variable and initialize it to value 0, 
--1. When the value of the variable is equal to 2, then insert another record into the table tblProject.
--2. When the value of the variable is equal to 10, then change the ProjectName to 'Project_New' for input @ProjectId

--In the next part of the stored procedure, return all the fields of the table tblProject(ProjectId,ProjectName,Code and Examyear)
--based on the ProjectId and for the column ExamYear display it as given using CASE statement.
--1.If the ExamYear is greater than or equal to 2022 then display 'New'
--2.If the ExamYear is lesser than or equal to 2022 then display 'Old'

CREATE OR ALTER PROCEDURE usp_UpdateProjectAndFetch
    @ProjectId INT,
    @Variable INT
AS
BEGIN
    BEGIN TRY
        DECLARE @CurrentValue INT = @Variable;

        -- DML Operation 1: Insert another record when @Variable is equal to 2
        IF @CurrentValue = 2
        BEGIN
            INSERT INTO tblProject (Name, Code, ExamYear)
            VALUES ('New Project', 'NP001', 2023);

            PRINT 'Record inserted into tblProject.';
        END

        -- DML Operation 2: Change ProjectName to 'Project_New' when @Variable is equal to 10
        ELSE IF @CurrentValue = 10
        BEGIN
            UPDATE tblProject
            SET Name = 'Project_New'
            WHERE ProjectId = @ProjectId;

            PRINT 'ProjectName updated in tblProject.';
        END

        -- Handle unexpected values of @Variable
        ELSE
        BEGIN
            THROW 50000, 'Unexpected value for @Variable. No DML operation performed.', 1;
        END

        -- Fetch all fields of tblProject based on ProjectId with ExamYear displayed as 'New' or 'Old'
        -- Fetch all fields of tblProject based on ProjectId with ExamYear displayed as 'New' or 'Old'
SELECT
    ProjectId,
   Name, -- Check if this column name is correct
    Code,
    CASE
        WHEN ExamYear >= 2022 THEN 'New'
        WHEN ExamYear <= 2022 THEN 'Old'
    END AS ExamYearDisplay
FROM
    tblProject
WHERE
    ProjectId = @ProjectId;


        PRINT 'Data fetched from tblProject.';
    END TRY
    BEGIN CATCH
        -- Handle exceptions
        PRINT 'Error: ' + ERROR_MESSAGE();
    END CATCH
END;

DECLARE @ProjectIdToUse INT = 1;
DECLARE @VariableValue INT = 2;

EXEC usp_UpdateProjectAndFetch @ProjectId = @ProjectIdToUse, @Variable = @VariableValue;



