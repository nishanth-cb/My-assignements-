create  TABLE tblCustomer (
    CustId VARCHAR(5) PRIMARY KEY,
    CustName VARCHAR(50) NOT NULL
);


create TABLE tblFlight (
    FlightId VARCHAR(5) PRIMARY KEY,
    FlightName VARCHAR(50) NOT NULL,
    FlightType VARCHAR(20) CHECK (FlightType IN ('International', 'Domestic')) NOT NULL,
    Source VARCHAR(50) NOT NULL,
    Destination VARCHAR(50) NOT NULL,
    FlightCharge INT NOT NULL,
    TicketsAvailable INT NOT NULL,
    TravelClass VARCHAR(20) CHECK (TravelClass IN ('Economy', 'Business')) NOT NULL
);

CREATE  TABLE tblBooking (
    BookingId INT PRIMARY KEY,
    FlightId VARCHAR(5),
    CustId VARCHAR(5),
    TravelClass VARCHAR(20) CHECK (TravelClass IN ('Economy', 'Business')) NOT NULL,
    NoOfSeats INT,
    BookingDate DATE,
    TotalAmt INT NOT NULL,
    FOREIGN KEY (FlightId) REFERENCES tblFlight(FlightId),
    FOREIGN KEY (CustId) REFERENCES tblCustomer(CustId)
);
-- Insert data into tblCustomer
INSERT INTO tblCustomer (CustId, CustName) VALUES
('C301', 'John'),
('C302', 'SAM'),
('C303', 'Robert'),
('C304', 'Albert'),
('C305', 'Jack');

-- Insert data into tblFlight
INSERT INTO tblFlight (FlightId, FlightName, FlightType, Source, Destination, FlightCharge, TicketsAvailable, TravelClass) VALUES
('F101', 'SPICE JET', 'Domestic', 'mumbai', 'Kolkata', 5000, 100, 'Business'),
('F102', 'indian', 'International', 'delhi', 'Germany', 10000, 50, 'Business'),
('F103', 'Deccan', 'Domestic', 'chennai', 'Bengaluru', 7000, 75, 'Economy'),
('F104', 'British', 'International', 'london', 'italy', 7000, 75, 'Economy'),
('F105', 'Swiss', 'International', 'Zurich', 'spain', 7000, 75, 'Business');


INSERT INTO tblBooking (BookingId, FlightId, CustId, TravelClass, NoOfSeats, BookingDate, TotalAmt) VALUES
(201, 'F101', 'C301', 'Business', 2, '2023-05-22', 10000),
(202, 'F105', 'C303', 'Business', 1, '2023-05-17', 10000),
(203, 'F103', 'C302', 'Economy', 3, '2023-05-23', 21000),
(204, 'F101', 'C302', 'Business', 3, '2023-05-12', 21000),
(205, 'F104', 'C303', 'Economy', 3, '2023-05-16', 21000),
(206, 'F105', 'C301', 'Business', 3, '2023-05-22', 21000),
(207, 'F104', 'C304', 'Economy', 3, '2023-05-16', 21000),
(208, 'F101', 'C304', 'Business', 3, '2023-05-18', 21000);

 

 SELECT * FROM tblFlight



-- by considering the above data 
-- take input parameters as no of seats, booking date , TotalAmt, FlightCharge, tickets available, TravelClass 
-- now give query for the procedure 
-- Stored Procedure: usp_BookTheTicket 
-- Functionality: 
--Check if CustId is present in tblCustomer 
--Check if FlightId is present in tblFlight 
--Check if NoOfTickets is a positive value and is less than or equal to TicketsAvailable 
--value for that flight 
--If all the validations are successful, insert the data by generating the BookingId and 
--calculate the total amount based on the TicketCost 
--Return Values: 
--1, in case of successful insertion 
---1,if CustId is invalid 
---2,if FlightId is invalid 
---3,if NoOfTickets is less than zero 
---4,if NoOfTickets is greater than TicketsAvailable 
---99,in case of any exception











--CREATE OR ALTER PROCEDURE usp_BookTheTicket(
--    @CustId VARCHAR(5),
--    @FlightId VARCHAR(5),
--    @NoOfTickets INT,
--    @TravelClass VARCHAR(20))
--AS
--BEGIN
--    SET NOCOUNT ON;

--    DECLARE @BookingId INT, @TicketCost DECIMAL(10, 2), @TotalAmt DECIMAL(10, 2);

--    -- Check if CustId is present in tblCustomer,FlightId is present in tblFlight
--    IF NOT EXISTS (SELECT 1 FROM tblCustomer WHERE CustId = @CustId)
--        RETURN -1;

    
--    IF NOT EXISTS (SELECT 1 FROM tblFlight WHERE FlightId = @FlightId)
--        RETURN -2;

--    -- Check if NoOfTickets is a positive value
--    IF @NoOfTickets <= 0
--        RETURN -3;

--    -- Check if NoOfTickets is less than or equal to TicketsAvailable for that flight
--    IF @NoOfTickets > (SELECT TicketsAvailable FROM tblFlight WHERE FlightId = @FlightId)
--        RETURN -4;

--    -- Generate BookingId
--    SELECT @BookingId = ISNULL(MAX(BookingId), 0) + 1 FROM tblBooking;

--    -- Calculate TicketCost and TotalAmt
--    SELECT @TicketCost = FlightCharge FROM tblFlight WHERE FlightId = @FlightId;
--    SET @TotalAmt = @TicketCost * @NoOfTickets;

--    BEGIN TRY
--        -- Insert data into tblBooking
--        INSERT INTO tblBooking (BookingId, FlightId, CustId, TravelClass, NoOfSeats, BookingDate, TotalAmt)
--        VALUES (@BookingId, @FlightId, @CustId, @TravelClass, @NoOfTickets, GETDATE(), @TotalAmt);

--        -- Return 1 for successful insertion
--        RETURN 1;
--    END TRY
--    BEGIN CATCH
--        -- Return -99 for any exception
--        RETURN -99;
--    END CATCH
--END;



CREATE OR ALTER PROCEDURE usp_BookTheTicket(
    @CustId VARCHAR(5),
    @FlightId VARCHAR(5),
    @NoOfTickets INT,
    @TravelClass VARCHAR(20),
    @AvailableTickets INT OUTPUT)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @BookingId INT, @TicketCost DECIMAL(10, 2), @TotalAmt DECIMAL(10, 2);

    -- Check if CustId is present in tblCustomer,FlightId is present in tblFlight
    IF NOT EXISTS (SELECT 1 FROM tblCustomer WHERE CustId = @CustId)
        RETURN -1;

    IF NOT EXISTS (SELECT 1 FROM tblFlight WHERE FlightId = @FlightId)
        RETURN -2;

    -- Check if NoOfTickets is a positive value
    IF @NoOfTickets <= 0
        RETURN -3;

    -- Check if NoOfTickets is less than or equal to TicketsAvailable for that flight
    IF @NoOfTickets > (SELECT TicketsAvailable FROM tblFlight WHERE FlightId = @FlightId)
        RETURN -4;

    -- Update available tickets
    UPDATE tblFlight
    SET TicketsAvailable = TicketsAvailable - @NoOfTickets
    WHERE FlightId = @FlightId;

    -- Get updated available tickets
    SET @AvailableTickets = (SELECT TicketsAvailable FROM tblFlight WHERE FlightId = @FlightId);

    -- Generate BookingId
    SELECT @BookingId = ISNULL(MAX(BookingId), 0) + 1 FROM tblBooking;

    -- Calculate TicketCost and TotalAmt
    SELECT @TicketCost = FlightCharge FROM tblFlight WHERE FlightId = @FlightId;
    SET @TotalAmt = @TicketCost * @NoOfTickets;

    BEGIN TRY
        -- Insert data into tblBooking
        INSERT INTO tblBooking (BookingId, FlightId, CustId, TravelClass, NoOfSeats, BookingDate, TotalAmt)
        VALUES (@BookingId, @FlightId, @CustId, @TravelClass, @NoOfTickets, GETDATE(), @TotalAmt);

        -- Return 1 for successful insertion
        RETURN 1;
    END TRY
    BEGIN CATCH
        -- Return -99 for any exception
        RETURN -99;
    END CATCH
END;



DECLARE @Result INT, @AvailableTickets INT;


EXEC @Result = usp_BookTheTicket 
    @CustId = 'C301',
    @FlightId = 'F101',
    @NoOfTickets = 6,
    @TravelClass = 'Business',
    @AvailableTickets = @AvailableTickets OUTPUT
    print @AvailableTickets









 
-- DECLARE @RESULT INT 

--EXEC @RESULT=usp_BookTheTicket
--    @CustId = 'C301'
--,   @FlightId = 'F101',
--    @NoOfTickets =102,
--    @TravelClass = 'BUSINESS'
--	PRINT @RESULT
SELECT * FROM tblCustomer
SELECT * FROM tblFlight
SELECT * FROM TBLBOOKING


	SELECT  * FROM tblBooking
	


	CREATE OR ALTER FUNCTION ufn_BookedDetails (@BookingId INT)
RETURNS TABLE
AS
RETURN
(
    SELECT
        B.BookingId,
        C.CustName,
        F.FlightName,
        F.Source,
        F.Destination,
        B.BookingDate,
        B.NoOfSeats AS NoOfTickets,
        B.TotalAmt
    FROM
        tblBooking B
        INNER JOIN tblCustomer C ON B.CustId = C.CustId
        INNER JOIN tblFlight F ON B.FlightId = F.FlightId
    WHERE
        B.BookingId = @BookingId
);


SELECT * FROM tblCustomer
SELECT * FROM tblFlight
SELECT * FROM TBLBOOKING



SELECT * FROM ufn_BookedDetails(201);
----------------------------------------------------------------------------------------------------
-----------------------------------------ASSESMENT-2-------------------------------

-----1.Identify the customer(s) who have not booked any flight tickets or not booked any 
--flights tickets of travel class �Economy�.Display custid and custname of the identified 
--customer(s). 
SELECT DISTINCT C.CustId, C.CustName
FROM tblCustomer C
INNER JOIN tblBooking B ON C.CustId = B.CustId
WHERE B.CustId IS NULL OR  B.TravelClass <> 'Economy';



--2.Identify the booking(s) with flightcharge greater than the average flightcharge of all the 
--flights booked for the same travel class. Display flightid, flightname and  custname of 
--the identified bookings(s). 

SELECT  B.FlightId,  C.CustName,F.FlightName
FROM tblBooking B
INNER JOIN tblFlight F ON B.FlightId = F.FlightId
INNER JOIN tblCustomer C ON B.CustId = C.CustId
WHERE F.FlightCharge > (
						SELECT AVG(F2.FlightCharge)
						FROM tblFlight F2
						WHERE F2.TravelClass = F.TravelClass )


SELECT * FROM [tblFlight]
SELECT * FROM [tblBooking]



--3.Identify the bookings done by the same customer for the same flight type and travel 
--class. Display flightid and the flighttype of the identified bookings. 


SELECT distinct B.FlightId,  F.FlightType, C.CustName
FROM tblBooking B
INNER JOIN tblFlight F ON B.FlightId = F.FlightId
INNER JOIN    tblCustomer C ON B.CustId = C.CustId
INNER JOIN (SELECT CustId,FlightId,  COUNT(*) AS BookingCount 
FROM  tblBooking
GROUP BY   CustId, FlightId
HAVING   COUNT(*) > 1
) AS Db ON B.CustId = db.CustId AND B.FlightId = db.FlightId;



--4.Identify the flight(s) for which the bookings are done to destination �Kolkata�, �Italy� or 
--�Spain�. Display flightid and flightcharge of the identified booking(s) in the increasing 
--order of flightname and decreasing order of flightcharge. 

SELECT  f.FlightId, f.flightName, f.destination,f.flightcharge
from tblflight f inner join tblBooking b on f.FlightId= b.FlightId 
Where f.Destination in ('Kolkata','Italy','Spain')
order by FlightName asc , flightcharge desc


--5.Identify the month(s) in which the maximum number of bookings are made. Display 
--custid and custname of the customers who have booked flights tickets in the identified 
--month(s). 

WITH MonthlyBookings AS (
    SELECT B.CustId, C.CustName,  MONTH(B.BookingDate) AS BookingMonth, 
	COUNT(B.BookingId) AS NumBookings
    FROM  tblBooking B
    INNER JOIN tblCustomer C ON B.CustId = C.CustId
    GROUP BY  B.CustId, C.CustName, MONTH(B.BookingDate)
)
SELECT CustId, CustName, BookingMonth
FROM MonthlyBookings
WHERE NumBookings = (SELECT MAX(NumBookings) FROM MonthlyBookings);


--Identify the booking(s) done in the year 2019 for the flights having the letter �u� 
--anywhere in their source or destination and booked by the customer having atleast 5 
--characters in their name. Display bookingid prefixed with �B� as �BOOKINGID� ( column 
--alias) and the numeric part of custid as �CUSTOMERID� (column alias) for the identified 
--booking(s).



Select 'B'+CAST(BookingId AS varchar(10)) AS BOOKINGID,
		CAST(SUBSTRING(c.CustId, 2, LEN(c.CustId))AS INT)AS CUSTOMERID
FROM tblBooking b inner join tblCustomer c on c.CustId= b.CustId
WHERE YEAR(BookingDate)=2019
and (b.FlightId in (SELECT FlightId FROM tblFlight WHERE Source like '%u%' or Destination like '%u%'))
	AND LEN((SELECT CustName FROM	tblCustomer where CustId = b.CustId))>=5;


--7.Identify the customer(s) who have booked the seats of travel class �Business� for 
--maximum number of times. Display custid and custname of the identified customer(s).  

--Using subquery 
SELECT custId, CustName from tblCustomer
where CustId IN (SELECT TOP 1 WITH TIES CustId from tblBooking 
WHERE TravelClass= 'Business'
GROUP BY CustId
order BY COUNT (CustId) desc )



--using join 

SELECT TOP 1 C.CustId,  C.CustName
FROM  tblBooking B
INNER JOIN tblCustomer C ON B.CustId = C.CustId
WHERE B.TravelClass = 'Business'
GROUP BY  C.CustId,  C.CustName
ORDER BY COUNT(B.BookingId) DESC;


--Identify the bookings done with the same flightcharge. For every customer who has 
--booked the identified bookings, display custname and bookingdate as �BDATE� (column 
--alias). Display �NA� in BDATE if the customer does not have any booking or if no such 
--booking is done by the customer. 


Select c.CustName, ISNULL(CONVERT(VARCHAR,b.bookingdate,120),'NA') as BDATE
from tblCustomer c LEFT OUTER  JOIN  tblBooking b 
on c.CustId=b.CustId INNER JOIN tblFlight f on b.FlightId=f.FlightId
where f.FlightCharge in (
						SELECT FlightCharge from tblFlight
						group by FlightCharge
						having COUNT(*)>1)



--9.Identify the customer(s) who have paid highest flightcharge for the travel class 
--economy. Write a SQL query to display id, flightname and name of the identified 
--customers. 

SELECT c.custId,f.flightName, c.CustName
from tblCustomer c inner join tblBooking b ON c.CustId=b.CustId
inner join tblFlight f on f.FlightId=b.FlightId
where b.TravelClass='Economy' and f.FlightCharge= (
			SELECT MAX(FlightCharge) from tblFlight
			where TravelClass='Economy')
group by c.custId,f.flightName, c.CustName



select * from tblFlight

--Identify the International flight(s) which are booked for the maximum number of 
--times.Write a SQL query to display id and name of the identified flights. 


SELECT TOP 1 F.flightId, F.FlightName,COUNT(b.bookingId)
FROM tblFlight f
inner join tblBooking b ON f.FlightId= b.FlightId
WHERE f.FlightType = 'International'
GROUP BY f.FlightId, f.FlightName
ORDER BY COUNT(b.bookingId) desc


--11.Identify the customer(s) who have bookings during the months of October 2018 to 
--January 2019 and paid overall total flightcharge less than the average flightcharge of all 
--bookings belonging to travel class �Business�. Write a SQL query to display id and name 
--of the identified customers. 

SELECT  c.CustId, c.CustName
FROM tblCustomer c
INNER JOIN tblBooking b ON c.CustId = b.CustId
INNER JOIN tblFlight F ON b.FlightId=F.FlightId
WHERE (MONTH(b.BookingDate) BETWEEN 10 AND 12 AND YEAR (b.BookingDate)=2018) OR
		(MONTH(b.BookingDate) =1   and  YEAR (b.BookingDate)=2019)
		and b.TravelClass='Business'
GROUP BY c.CustId, c.CustName
HAVING SUM(F.FlightCharge) < (SELECT AVG(F.FlightCharge)FROM tblFlight)


--12.Identify the bookings with travel class �Business� for the International flights.
--Write a SQL 
--query to display booking id, flight id and customer id of those customer(s) not having 
--letter �e� anywhere in their name and have booked the identified flight(s). 


SELECT DISTINCT  b1.BookingId,F1.FlightId,C1.CustId
FROM tblBooking b1 INNER JOIN tblFlight F1 ON f1.FlightId= b1.FlightId
INNER JOIN tblCustomer C1 ON   c1.CustId = b1.CustId
WHERE B1.TravelClass='Business' AND    C1.CustName NOT LIKE '%E%'
GROUP BY C1.CustId,b1.BookingId,  F1.FlightId



--13.Identify the booking(s) which have flight charges paid is less than the average flight 
--charge for all flight ticket bookings belonging to same flight type. Write a SQL query to 
--display booking id, source city, destination city and booking date of the identified 
--bookings. 

SELECT B1.BookingId, F1.Source, F1.Destination,B1.BookingDate,F1.FlightCharge
FROM tblFlight F1 INNER JOIN tblBooking B1 
ON F1.FlightId=B1.FlightId
where  B1.TotalAmt < (SELECT AVG(F.FlightCharge) FROM tblFlight F WHERE F.FlightType = F.FlightType)


--14.Write a SQL query to display customer�s id and name of those customers who have paid 
--the flight charge which is more than the average flightcharge for all international flights. 
   
   SELECT C1.CustId, C1.CustName FROM tblCustomer C1 
   INNER JOIN tblBooking B1 ON  C1.CustId=B1.CustId
    INNER JOIN tblFlight F1 ON  B1.FlightId=F1.FlightId
	WHERE   F1.FlightType = 'International' AND B1.TotalAmt> (SELECT AVG(FlightCharge) FROM tblFlight WHERE F1.FlightType = 'International')
	

--15.Identify the customer(s) who have booked tickets for all types of flights. Write a SQL 
--query to display name of the identified customers. 
--Note: The types of flight are not only the ones defined in the sample data. . 



	SELECT C.CustName
FROM  tblCustomer C
WHERE NOT EXISTS ( SELECT DISTINCT F.FlightType  FROM tblFlight F
        WHERE NOT EXISTS (
            SELECT 1 FROM tblBooking B
            WHERE B.CustId = C.CustId
              AND B.FlightId = F.FlightId
        )
    )




--16.Display flight id of the booked flight tickets, which fulfills EITHER of these requirements: 
--Flight�s id of the booked flight tickets that are booked for maximum number of times for the 
--travel class �Business� 
--Total flight charge of a flight id of booked flight tickets is more than the average flight charge 
--of all bookings done for the same flight for travel class �Economy�. 


SELECT TOP 1 WITH TIES B.FlightId, COUNT(B.BookingId) AS BookingCount
FROM tblBooking B
WHERE B.TravelClass = 'Business'
GROUP BY B.FlightId
ORDER BY BookingCount DESC;

SELECT DISTINCT B.FlightId
FROM tblBooking B
WHERE B.TravelClass = 'Economy'
  AND (SELECT AVG(B2.TotalAmt) FROM tblBooking B2 WHERE B2.FlightId = B.FlightId AND B2.TravelClass = 'Economy') < B.TotalAmt;



SELECT * FROM tblCustomer
SELECT * FROM tblFlight
SELECT * FROM TBLBOOKING


------------------------------------------------------------------------------------------------------------
---------------------
