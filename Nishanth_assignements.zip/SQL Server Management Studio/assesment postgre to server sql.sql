-- Create tblUsers table
CREATE TABLE tblUsers (
    User_id INT PRIMARY KEY IDENTITY(1,1),
    User_name VARCHAR(255),
    Email VARCHAR(255)
);

-- Insert data into tblUsers
INSERT INTO tblUsers (User_name, Email) VALUES
    ('Akash', 'akash@gmail.com'),
    ('Arvind', 'arvind123@gmail.com'),
    ('Sakshi', 'sakshimys12@gmail.com'),
    ('Kumar', 'kumar987@gmail.com');

-- Create tblCategory table
CREATE TABLE tblCategory (
    Category_id INT PRIMARY KEY IDENTITY(1,1),
    Category_name VARCHAR(255),
    Description VARCHAR(255)
);

-- Insert data into tblCategory
INSERT INTO tblCategory (Category_name, Description) VALUES
    ('Electronics', 'One stop for electronic items.'),
    ('Apparel', 'Apparel is the next destination for fashion.'),
    ('Grocery', 'All needs in one place.');

-- Create tblProducts table
CREATE TABLE tblProducts (
    Product_id INT PRIMARY KEY IDENTITY(1,1),
    Product_name VARCHAR(255),
    Quantity INT,
    Product_price DECIMAL(10, 2),
    Category_id INT FOREIGN KEY REFERENCES tblCategory(Category_id)
);

-- Insert data into tblProducts
INSERT INTO tblProducts (Product_name, Quantity, Product_price, Category_id) VALUES
    ('Mobile Phone', 1000, 15000.00, 1),
    ('Television', 500, 40000.00, 1),
    ('Denims', 2000, 700.00, 2),
    ('Vegetables', 4000, 40.00, 3),
    ('Ethnic Wear', 300, 1500.00, 2),
    ('Wireless Earphone', 5000, 2500.00, 1),
    ('Lounge Wear', 200, 1600.00, 2),
    ('Refrigerator', 50, 30000.00, 1),
    ('Pulses', 60, 150.00, 2),
    ('Fruits', 100, 250.00, 2);

-- Create tblSales table
CREATE TABLE tblSales (
    Sales_id INT PRIMARY KEY IDENTITY(1,1),
    Sales_user_id INT FOREIGN KEY REFERENCES tblUsers(User_id),
    Product_id INT FOREIGN KEY REFERENCES tblProducts(Product_id)
);

-- Insert data into tblSales
INSERT INTO tblSales (Sales_user_id, Product_id) VALUES
    (1, 1),
    (2, 1),
    (3, 2),
    (4, 3),
    (4, 1),
    (4, 1),
    (2, 2),
    (3, 1),
    (1, 7),
    (1, 8);

-- Create the function
-- Create the function

CREATE OR ALTER  FUNCTION Salesfunc(@saleid INT)
RETURNS  TABLE
AS
	RETURN
	SELECT product_name,category_name,user_name,product_price, 
	CASE
		WHEN (product_price > 2000) THEN 'The product has gained profit'
		WHEN (product_price BETWEEN 1000 AND 2000 ) THEN 'AVERAGE PROFIT'
		WHEN (product_price) BETWEEN 500 AND 1000 THEN 'The product has occured loss'
		WHEN (product_price) < 500 THEN 'No profit no loss'
	END
	)AS profit_loss
	FROM tblusers tu
	JOIN tblsales ts
	ON ts.sales_user_id = tu.user_id
	JOIN tblProducts tp
	ON ts.product_id = tp.product_id
	JOIN tblcategory tc
	ON tp.category_id = tc.category_id
	WHERE sales_id = @saleid

	select * from dbo.Salesfunc(11)


 SELECT * FROM tblUsers
 SELECT * FROM tblCategory
 SELECT * FROM tblProducts
 SELECT * FROM tblSales
 
 INSERT INTO  tblSales(Sales_user_id, Product_id) VALUES(3, 5)

	--procedure 




CREATE OR ALTER PROCEDURE usp_update
    @userid INT
AS
BEGIN
    BEGIN TRY
        -- Check if the user has sales records
        IF NOT EXISTS (SELECT 1 FROM dbo.tblsales WHERE Sales_user_id = @userid)
        BEGIN
            PRINT 'USER BOUGHT NOTHING IN THE STORE';
            RETURN;
        END;

        BEGIN TRANSACTION;

        -- Update category name
        UPDATE dbo.tblcategory
        SET Category_name = 'Modern Gadgets'
        WHERE Category_name = 'Electronics';

        COMMIT;

        SELECT 
            C.Category_name,
            P.Product_name,
			SUM(P.Product_price) as Toatal_value
        FROM
            dbo.tblcategory C
        INNER JOIN
            dbo.tblproducts P ON C.category_id = P.category_id
        INNER JOIN
            dbo.tblsales S ON S.product_id = P.product_id
        WHERE
            S.Sales_user_id = @userid;
		Group by  C.Category_name, P.Product_name
    END TRY
    BEGIN CATCH
        -- Handle exceptions
        IF @@TRANCOUNT > 0
            ROLLBACK;

        DECLARE @ErrorMessage NVARCHAR(4000),
                @ErrorSeverity INT,
                @ErrorState INT;

        SELECT 
            @ErrorMessage = ERROR_MESSAGE(),
            @ErrorSeverity = ERROR_SEVERITY(),
            @ErrorState = ERROR_STATE();

    END CATCH;
END;


EXEC usp_update @userid = 1  

 SELECT * FROM tblUsers
 SELECT * FROM tblCategory
 SELECT * FROM tblProducts
 SELECT * FROM tblSales

 


















--CREATE OR ALTER FUNCTION dbo.fetch_productdtls (@saleid INT)
--RETURNS TABLE
--AS
--RETURN
--(
--    SELECT *,
--        p.product_name,
--        c.category_name,
--        u.user_name,
--        p.product_price AS product_cost
--    FROM 
--        dbo.tblSales s
--    INNER JOIN 
--        dbo.tblUsers u ON s.sales_user_id = u.user_id
--    INNER JOIN 
--        dbo.tblProducts p ON s.product_id = p.product_id
--    INNER JOIN 
--        dbo.tblCategory c ON p.category_id = c.category_id
--    WHERE 
--        s.sales_id = @saleid
--);

--DECLARE @product_name VARCHAR(255),
--        @category_name VARCHAR(255),
--        @user_name VARCHAR(255),
--        @product_cost DECIMAL(10, 2);

--SELECT 
--    @product_name = product_name,
--    @category_name = category_name,
--    @user_name = user_name,
--    @product_cost = product_cost
--FROM 
--    dbo.fetch_productdtls(5) ;

--DECLARE @product_name VARCHAR(255),
--        @category_name VARCHAR(255),
--        @user_name VARCHAR(255),
--        @product_cost DECIMAL(10, 2);
--SELECT 
--    *
--FROM 
--    dbo.fetch_productdtls(5) ;

--IF @product_cost > 2000
--    PRINT 'The product has gained profit';
--ELSE IF @product_cost BETWEEN 500 AND 1000
--    PRINT 'The product has occurred loss';
--ELSE IF @product_cost < 500
--    PRINT 'No profit no loss';






--CREATE or alter  PROCEDURE usp_update
--    @userid INT
--AS
--BEGIN
--    -- Check if the user has sales records
--    IF NOT EXISTS (SELECT 1 FROM tblsales WHERE Sales_user_id = @userid)
--    BEGIN
--        print('USER BOUGHT NOTHING IN THE STORE');
--        RETURN;
--    END;

--    -- Start a transaction
--    BEGIN TRANSACTION;

--		-- Update category name
--		UPDATE tblcategory
--		SET Category_name = 'Modern Gadgets'
--		WHERE Category_name = 'Electronics';

--	-- Commit the transaction
--    COMMIT;

--    -- Retrieve category and product info
--    SELECT 
--		C.Category_name,
--        P.Product_name
--    FROM
--        dbo.tblcategory C
--    INNER JOIN
--        dbo.tblproducts P ON C.category_id = P.category_id
--    INNER JOIN
--        dbo.tblsales S ON S.product_id = P.product_id
--    WHERE
--        S.Sales_user_id = @userid;

    
--END;
