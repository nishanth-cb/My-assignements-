CREATE TABLE tblEmployeeDtlC (
    EmployeeID INT PRIMARY KEY,
    EmployeeName VARCHAR(50) NOT NULL,
    Designation VARCHAR(50) NOT NULL,
    JoiningDate DATETIME NOT NULL DEFAULT GETDATE(),
    EmailId VARCHAR(25) NOT NULL UNIQUE,
    PhoneNo VARCHAR(10) NOT NULL,
    Salary INT NOT NULL CHECK (Salary > 15000),
    DepartmentID INT,
    FOREIGN KEY (DepartmentID) REFERENCES tblDepartmentC(DepartmentID)
);

CREATE TABLE tblDepartmentC (
    DepartmentID INT PRIMARY KEY,
    DepartmentName VARCHAR(50) NOT NULL,
    Location VARCHAR(50) NOT NULL
);


CREATE TABLE tblSubjectDtl (
    SubjectID INT PRIMARY KEY,
    SubjectName VARCHAR(50) NOT NULL
);


create TABLE tblStudentDtl (
    StudentID INT PRIMARY KEY,
    StudentName VARCHAR(50) NOT NULL
);


create TABLE tblStudentSubMarks (
    StudentID INT,
    SubjectID INT,
    Marks DECIMAL NOT NULL,
    PRIMARY KEY (StudentID, SubjectID),
    FOREIGN KEY (StudentID) REFERENCES tblStudentDtl(StudentID),
    FOREIGN KEY (SubjectID) REFERENCES tblSubjectDtl(SubjectID)
);

INSERT INTO tblEmployeeDtlC (EmployeeID, EmployeeName, Designation, EmailId, PhoneNo, Salary, DepartmentID)
VALUES
    (1, 'nishanth', 'Manager', 'nishanth@example.com', '1234567890', 50000, 1),
    (2, 'sagar', 'Sales Representative', 'sagar@example.com', '9876543210', 40000, 2),
    (3, 'anjali', 'Finance Analyst', 'anjali@example.com', '7890123456', 35000, 3),
    (4, 'Prajwal', 'Software Engineer', 'Prajwal@example.com', '3456789012', 30000, 4);


	INSERT INTO tblDepartmentC (DepartmentID, DepartmentName, Location)
VALUES
    (1, 'HR', 'Mysuru'),
    (2, 'Sales', 'Mandya'),
    (3, 'Finance', 'madikeri'),
    (4, 'IT', 'Hassan');



	INSERT INTO tblSubjectDtl (SubjectID, SubjectName)
VALUES
    (1, 'Mathematics'),
    (2, 'Science'),
    (3, 'History'),
    (4, 'English');


	INSERT INTO tblStudentDtl (StudentID, StudentName)
VALUES
    (1, 'Nishanth'),
    (2, 'Sagar'),
    (3, 'Cena'),
    (4, 'saul goodman');

	INSERT INTO tblStudentSubMarks (StudentID, SubjectID, Marks)
VALUES
    (1, 1, 95.50),
    (1, 2, 88.25),
    (2, 1, 92.75),
    (2, 2, 76.00);


select * from tblStudentSubMarks


Select *,salary + coalesce(bonus,0) as [total_salary]
from tblEmployeeDtlC

Select *,salary + ISNULL(bonus,0) as [total_salary]
from tblEmployeeDtlC

---query1
Alter table tblEmployeeDtlC
drop column Bonus;

update tblEmployeeDtlC
set DepartmentID=null 
where Designation= 'Software Engineer';

--query2 

update tblEmployeeDtlC 
set bonus= 10000
where DATEDIFF(YYYY, JoiningDate, GETDATE()) >=2;


--query3

SELECT *--,EmployeeID, EmployeeName, (salary+ISNULL(Bonus,0)) as total_salary 
from tblEmployeeDtlC

SELECT EmployeeID+DepartmentID
FROM tblEmployeeDtlC;

select * from tblEmployeeDtlC

update tblEmployeeDtlC 
set JoiningDate = '2021-10-11'
where EmployeeID=1;

alter table tblEmployeeDtlC
add bonus int










---ASSIGNEMENT 4 


-- Create the 'salesmen' table
CREATE TABLE salesmen (
    snum INT PRIMARY KEY,
    sname VARCHAR(20),
    city VARCHAR(20),
    commission DECIMAL(6, 2)
);

-- Insert values into the 'salesmen' table
INSERT INTO salesmen (snum, sname, city, commission)
VALUES
    (1001, 'Piyush', 'London', 0.11),
    (1002, 'Sejal', 'Surat', 0.10),
    (1004, 'Rashmi', 'London', 0.21),
    (1007, 'Rajesh', 'Baroda', 0.14),
    (1003, 'Anand', 'New Delhi', 0.15);

-- Create the 'customers' table
CREATE TABLE customers (
    cnum INT PRIMARY KEY,
    cname VARCHAR(20),
    city VARCHAR(20),
    rating INT,
    snum INT
);

-- Insert values into the 'customers' table
INSERT INTO customers (cnum, cname, city, rating, snum)
VALUES
    (2001, 'Harsh', 'London', 100, 1001),
    (2002, 'Gita', 'Rome', 200, 1003),
    (2003, 'Lalit', 'Surat', 200, 1002),
    (2004, 'Govind', 'Bombay', 300, 1002),
    (2006, 'Chirag', 'London', 100, 1001),
    (2008, 'Chinmay', 'Surat', 300, 1007),
    (2007, 'Pratik', 'Rome', 100, 1004);

-- Create the 'orders' table
CREATE TABLE orders (
    onum INT PRIMARY KEY,
    amount DECIMAL(7, 2),
    odate DATETIME,
    cnum INT REFERENCES customers(cnum),
    snum INT REFERENCES salesmen(snum)
);

-- Insert values into the 'orders' table
INSERT INTO orders (onum, amount, odate, cnum, snum)
VALUES
    (3001, 18.69, '2006-10-03', 2008, 1007),
    (3003, 767.19, '2006-10-03', 2001, 1001),
    (3002, 1900.10, '2006-10-03', 2007, 1004),
    (3005, 5160.45, '2006-10-03', 2003, 1002),
    (3006, 1098.16, '2006-10-03', 2008, 1007),
    (3009, 1713.23, '2006-10-04', 2002, 1003),
    (3007, 75.75, '2006-10-04', 2004, 1002),
    (3008, 4723.00, '2006-10-05', 2006, 1001),
    (3010, 1309.95, '2006-10-06', 2004, 1002),
    (3011, 9891.88, '2006-10-06', 2006, 1001);



	Select * from  salesmen
	Select * from  orders
	Select * from  customers



---1 1.Display the following information about each order. a.Order No, Customer Name, Order Amount, Order Date 



select o.onum, c.cname, o.amount, o.odate
from orders o inner join customers c 
on o.cnum= c.cnum 


----2.Display customers associated with each Salesman 


select c.cname, s.sname from 
customers c  inner join salesmen s
on c.snum=s.snum



----3 3.Display following information about each order: a.OrderNo , Customer Name, Salesman Name, Order Amount, Order Date 


select o.onum, c.cnum, s.sname , o.amount, o.odate from 
orders o inner join customers c on o.cnum=c.cnum
 left outer join salesmen s on c.snum= s.snum


 ----4 Display salesman with their order details in the decreasing order value(Include salesman who has not captured any order) a.Salesman name, Customer name,Ordervalue 

 
 
 select s.sname, c.cname , o.amount
 from salesmen s left outer join customers c on s.snum= c.snum
   inner join  orders o on o.cnum =c.cnum
 order by amount desc



 ----5 5.Display customers with their orders in the ascending order of date(Include customers who hasn�t booked any order) a.Customer Name, Order Value Order date 


 select o.odate , c.cname , o.amount
 from customers c left join orders o on o.cnum= c.cnum
 order by odate asc 


 ----6 6.List the number of customers handled by each salesman.(Sales man name, Number of Customers handled) 

 select count(c.cnum), s.sname from 
 customers c right join  salesmen s 
 on c.snum=s.snum
 group  by sname


 ----7 7.List the customers(Name of the customer) who have placed more than one order 


 select c.cname, count(o.onum) as countofordernum  from customers c
 left join orders o on o.cnum=c. cnum 
 group by cname 
 having count(onum)> 1


 ----8 8.Display sum of orders from each city from each customer and salesman

 select count(o.amount) as totalorder, s.city , c.city  from 
customers c inner join orders o on o.cnum=c.cnum
  inner join salesmen s on c.cnum= s.snum
 group by s.city, c.city

 select  * from salesmen
  select  * from customers
   select  * from orders




  ---selfjoin 



---no of employee reporting to the manager 

 Select E2.managerId,count(E1.employeeID)
 from tblEmployee e1 inner join tblemployee e2 
 ON e1.managerId=e2.employeeID
 group by E2.managerId

 -----at least one 

 select employeeID, count(E1.employee)
 from tblemployee E1 inner join tblemployee e2 
 on E1.managerID=E2.employeeId
 group by E2.managerId
 having count(e1.employeeid)>0




---Assignement 5

create table customer(
custId int Primary key,
custname varchar(50) not null,
custtype char(1)
)


create table category(
Cid char(4)Primary key,
Cname varchar(50))


create table toys(
ToyId char(5) primary key,
Toyname varchar(50) Unique not null,
Cid char(4) references category(Cid) not null,
price Money not null ,
stock int not null
)

create table transactions(
TxnId int primary key,
custId int references customer(custid),
ToyId char(5) references toys (ToyId),
Quantity int, 
TxnCost int)


select * from customer 


---1.Display CustName and total transaction cost as TotalPurchase for those customers whose total transaction cost is greater than 1000. 

select   c.custname , sum(T.TxnCost)as TotalPurchase from 
customer c inner join transactions t on c.custId=t.custId
group by c.custname
having sum(t.TxnCost) >1000

---2.List all the toyid, total quantity purchased as 'total quantity' irrespective of the 
--customer. Toys that have not been sold should also appear in the result with total units as 0 

select t.toyId, COALESCE(count(t1.quantity), 0)from 
toys t inner join transactions t1 on 
t.toyId=t1.ToyId
group by t.toyId


----3.The CEO of Toys corner wants to know which toy has the highest total Quantity sold. 
---Display CName, ToyName, total Quantity sold of this toy. 

SELECT TOP 1
    c.Cname AS CategoryName,
    t.Toyname AS ToyName,
    SUM(tr.Quantity) AS TotalQuantitySold
FROM 
    category c
JOIN 
    toys t ON c.Cid = t.Cid
JOIN 
    transactions tr ON t.ToyId = tr.ToyId
GROUP BY 
    c.Cname, t.Toyname
ORDER BY 
    TotalQuantitySold DESC;





select * from toys
select * from category
select * from customers
select * from transactions




----Assignement Doctor 

create table pateint (
pId int primary key ,
pName varchar(50),
city varchar(50))


create table doctor (
dId varchar(11) primary key ,
dName varchar (50),
dept varchar(50),
salary int )

create table consultation(
cId int primary key ,
pId int references pateint(pId),
dId varchar(11) references doctor(dId),
fees int)




select * from pateint
select * from consultation
select * from doctor



--Identify the consultation details of patients with the letter �e� anywhere in their name, who 
--have consulted a cardiologist. Write a SQL query to display doctor�s name and patient�s 
--name for the identified consultation details. 

Select p.pId,p.pName,p.city,c.cId,c.fees,d.dName from consultation c
inner join pateint p on 
c.pId=p.pId left join doctor d on c.dId=d.dId
where pName like'%e%'




---Identify the doctors who have provided consultation to patients from the cities �Boston� 
---and �Chicago�. Write a SQL query to display department and number of patients as 
---PATIENTS who consulted the identified doctor(s). 

SELECT d.did,d.dname AS Doctor_Name,p.city
FROM pateint p
inner JOIN consultation
ON consultation.pid = p.pid
inner JOIN doctor d 
on consultation.did = d.did
WHERE p.city IN ('Boston','Chicago');
  

---Identify the cardiologist(s) who have provided consultation to more than one patient. 
---Write a SQL query to display doctor�s id and doctor�s name for the identified 
---cardiologists. 

SELECT d.dId,d.dname AS Doctor_Name
FROM pateint
JOIN consultation
ON consultation.pId = pateint.pId
JOIN doctor d
on consultation.did = d.did
WHERE d.dept = 'Cardiology'
GROUP BY d.did,d.dname
HAVING COUNT(d.did) >1;


/*
Question 4: Write a SQL query to combine the results of the following two reports into a single report.
The query result should NOT contain duplicate records.
Report 1 � Display doctor�s id of all cardiologists who have been consulted by
patients.
Report 2 � Display doctor�s id of all doctors whose total consultation fee charged
in the portal is more than INR 800.
*/

SELECT d.did
FROM pateint p
JOIN consultation
ON consultation.pid = p.pid
JOIN doctor d
on consultation.dId = d.did
GROUP BY d.did,d.dname
HAVING COUNT(d.did) >=1
UNION
SELECT d.did
FROM pateint p
JOIN consultation
ON consultation.pid = p.pid
JOIN doctor d
on consultation.did = d.did
WHERE consultation.fees  > 800



/*
Question 5: Write a SQL query to combine the results of the following two reports into a single report.
The query result should NOT contain duplicate records.
Report 1 � Display patient�s id belonging to �New York� city who have consulted
with the doctor(s) through the portal.
Report 2 � Display patient�s id who have consulted with doctors other than
cardiologists and have paid a total consultation fee less than INR 1000.
*/


SELECT p.pid
FROM pateint p INNER
JOIN consultation
ON consultation.pid = p.pid
inner JOIN doctor d
on consultation.did = d.did
WHERE p.city = 'New York'
UNION
SELECT p.pid
FROM pateint p
inner JOIN consultation
ON consultation.pid = p.pid
inner JOIN doctor
on consultation.did = doctor.did
WHERE consultation.fees  < 1000 AND doctor.dept != 'cardiology';




select * from pateint
select * from consultation
select * from doctor




--Banking


create table accountType(
AccType int primary key ,
AccName varchar(30))

create table transactionType(
TransType int primary key,
TransName varchar (50))

create table CustomerDetails (
 AccNo int primary key,
 CustName varchar(50),
 address varchar(50),
 AccType int references AccountType(Acctype))


create table AccountTransaction (
Tid int primary key ,
AccNo int references CustomerDetails(AccNo),
Amount money,
dateoftrans date,
TransType int references TransactionType(transtype))






-- Insert data into the AccountType table
INSERT INTO AccountType (AccType, AccName)
VALUES
    (1, 'Savings Account'),
    (2, 'Checking Account'),
    (3, 'Fixed Deposit'),
    (4, 'Credit Card'),
    (5, 'Loan Account');

-- Insert data into the TransactionType table
INSERT INTO TransactionType (TransType, TransName)
VALUES
    (1, 'Deposit'),
    (2, 'Withdrawal'),
    (3, 'Transfer'),
    (4, 'Payment'),
    (5, 'Purchase');

-- Insert data into the CustomerDetails table
INSERT INTO CustomerDetails (AccNo, CustName,address, AccType)
VALUES
    (1001, 'John Smith','Mysore', 1),
    (1002, 'Mary Johnson','bengaluru', 2),
    (1003, 'David Lee','mandya', 3),
    (1004, 'Sara Clark','madikeri', 1),
    (1005, 'Robert White','mangaluru', 2);
	

-- Insert data into the AccountTransaction table
INSERT INTO AccountTransaction (Tid, AccNo, Amount, dateoftrans, TransType)
VALUES
    (2001, 1001, 1000.00, '2023-10-15', 1),
    (2002, 1002, 500.00, '2023-10-16', 2),
    (2003, 1003, 15000.00, '2023-10-17', 1),
    (2004, 1001, 250.00, '2023-10-18', 4),
    (2005, 1005, 3000.00, '2023-10-19', 3);



--1.List the Customer with transaction details who has done third lowest  
--transaction 


SELECT Top 1 CustomerDetails.CustName,AccountTransaction.Amount
FROM CustomerDetails
INNER JOIN AccountTransaction
ON AccountTransaction.AccNo = CustomerDetails.AccNo
WHERE AccountTransaction.Amount NOT IN (SELECT TOP 2 AccountTransaction.Amount
FROM AccountTransaction
ORDER BY AccountTransaction.Amount DESC)
ORDER BY AccountTransaction.Amount DESC;


select * from AccountTransaction
--2.List the customers who has done more transactions than average number of  transaction  

 select count(tid)  from AccountTransaction
 group by  AccNo
 --- from inner subquery , find the average number of transaction  




/*3.List the total transactions under each account type. */

SELECT AccountTransaction.AccNo,COUNT(AccountTransaction.Tid) AS NUM_OF_TRANS
FROM AccountTransaction
GROUP BY AccountTransaction.AccNo;

/*4.List the total amount of transaction under each account type */

SELECT AccountTransaction.AccNo,SUM(AccountTransaction.Amount) AS NUM_OF_TRANS
FROM AccountTransaction
GROUP BY AccountTransaction.AccNo;

/*5. List the total tranctions along with the total amount on a Sunday. */

SELECT Tid,COUNT(Tid),SUM(AccountTransaction.Amount) AS NUM_OF_TRANS
FROM AccountTransaction
WHERE DATENAME(DW,DateOfTrans) = 'sunday'
GROUP BY Tid;


/*
7. List the total amount of transactions of Mysore customers.
*/

SELECT SUM(AccountTransaction.Amount) AS Total_Amt
FROM AccountTransaction
INNER JOIN CustomerDetails
ON CustomerDetails.AccNo = AccountTransaction.AccNo
WHERE address = 'Mysore'


select * from AccountTransaction 
select * from CustomerDetails 

/*
8. List the name,account type and the number of transactions performed by each customer
*/

SELECT CustomerDetails.CustName,AccountType.AccName,COUNT(AccountTransaction.Tid) AS NUM_OF_Transaction
FROM CustomerDetails
left outer JOIN AccountTransaction
ON CustomerDetails.AccNo = AccountTransaction.AccNo
inner JOIN AccountType
ON CustomerDetails.AccType = AccountType.AccType
GROUP BY CustomerDetails.CustName,AccountType.AccName;



/*9. List the amount of transaction from each Location. */

SELECT CustomerDetails.address,COUNT(AccountTransaction.Tid)
FROM AccountTransaction
INNER JOIN CustomerDetails
ON CustomerDetails.AccNo = AccountTransaction.AccNo
GROUP BY CustomerDetails.address;


/*10. Find out the number of customers  Under Each Account Type */

SELECT a.AccName,COUNT(c.Accno) AS Number_Of_Customer
FROM AccountType a left outer join CustomerDetails c
on a.AccType=c.AccType
GROUP BY a.AccName;


select * from accountType
select * from transactionType
select * from CustomerDetails
select * from AccountTransaction 



create table  tblstudentsdtl(
Sname varchar(50),
subbname varchar(50),
marks int ,
grade varchar(5)
)

create table stud(
 stuid int primary key ,
 Sname varchar(50))

 create table subj(
 subid int primary key ,
 subname varchar(50))

 create table stusubmar(
 stuId int  references stud(stuId) ,
 subId int references subj(subid),
 marks int )


 create table gradedh
 (lbound int,
 ubound int ,
 grade varchar(5))


 select * from tblstudentsdtl
 select * from stud
 select * from subj
 select * from stusubmar
 select * from gradedh




 