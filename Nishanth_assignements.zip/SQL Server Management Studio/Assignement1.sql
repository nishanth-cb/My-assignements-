-- Create tblDepartment
CREATE TABLE tblDepartment (
    DepartmentID INT PRIMARY KEY,
    DepartmentName VARCHAR(50) NOT NULL,
    Location VARCHAR(50) NOT NULL
);

-- Insert 10 records into tblDepartment
INSERT INTO tblDepartment (DepartmentID, DepartmentName, Location)
VALUES
    (10, 'HR', 'New York'),
    (20, 'Sales', 'Los Angeles'),
    (30, 'Finance', 'Chicago'),
    (40, 'IT', 'San Francisco'),
    (50, 'Marketing', 'Delhi'),
    (60, 'Operations', 'bengaluru'),
    (70, 'R&D', 'Mumbai'),
    (80, 'Customer Support', 'Chennai'),
    (90, 'Legal', 'kolkata'),
    (100, 'Production', 'Pune');

-- Create tblEmployee
CREATE TABLE tblEmployee (
    EmployeeID INT PRIMARY KEY,
    EmployeeName VARCHAR(50) NOT NULL,
    Designation VARCHAR(50) NOT NULL,
    JoiningDate DATETIME NOT NULL,
    EmailId VARCHAR(25) NOT NULL UNIQUE,
    Salary INT NOT NULL,
    DepartmentID INT,
    FOREIGN KEY (DepartmentID) REFERENCES tblDepartment (DepartmentID)
);

-- Insert 10 records into tblEmployee
INSERT INTO tblEmployee (EmployeeID, EmployeeName, Designation, JoiningDate, EmailId, Salary, DepartmentID)
VALUES
    (1, 'Nishanth', 'Manager', '2022-01-15', 'Nishanth@example.com', 50000, 10),
    (2, 'Sagar', 'Sales Representative', '2022-02-20', 'agar@example.com', 40000, 20),
    (3, 'roman', 'Finance Analyst', '2022-03-10', 'Roman@example.com', 35000, 30),
    (4, 'kendall', 'Software Engineer', '2022-04-05', 'kendall@example.com', 30000, 40),
    (5, 'Sarah', 'Marketing Specialist', '2022-05-12', 'sarah@example.com', 28000, 50),
    (6, 'greg', 'Operations Manager', '2022-06-22', 'greg@example.com', 45000, 60),
    (7, 'tom', 'Research Scientist', '2022-07-14', 'tom@example.com', 38000, 70),
    (8, 'roy', 'Customer Support Representative', '2022-08-19', 'roy@example.com', 32000, 80),
    (9, 'stewie', 'Legal Advisor', '2022-09-25', 'steiweie@example.com', 42000, 90),
    (10, 'martia', 'Production Supervisor', '2022-10-30', 'david.hall@example.com', 36000, 100);



	--1-- Display table information for tblEmployee
select * from tblEmployee

-- Display table information for tblDepartment

select * from tblDepartment


--2---
SELECT Employee_FirstName, EmployeeID, DepartmentID
FROM tblEmployee;

---3

SELECT Employee_FirstName, EmployeeID, DepartmentID
FROM tblEmployee
WHERE DepartmentID IN (20, 40);

5----
SELECT *
FROM tblEmployee
WHERE Designation = 'Trainees Software Engineer' AND Salary < 20000;

6---
SELECT *
FROM tblEmployee
WHERE DepartmentID = 30 AND Salary > 20000;


--7----

SELECT *
FROM tblEmployee
WHERE DepartmentID IS NULL;


--8---

SELECT Employee_FirstName,Designation
FROM tblEmployee
WHERE Designation = 'Business Analyst';




--9---

SELECT Employee_FirstName, Designation, Salary
FROM tblEmployee
WHERE DepartmentID = 30 AND Salary BETWEEN 20000 AND 40000;



10---

SELECT DISTINCT Designation
FROM tblEmployee;


--11--
SELECT *
FROM tblEmployee
WHERE DepartmentID IN (20, 30) AND Salary > 20000

--12---

SELECT Designation, DepartmentID, 
       FORMAT(JoiningDate, 'dd-MM-yyyy') AS JoinedDate
FROM tblEmployee
WHERE DepartmentID = 20;




13

SELECT *
FROM tblEmployee
WHERE SUBSTRING(Employee_FirstName, 1, 1) IN ('A', 'E', 'I', 'O', 'U');


14

SELECT *
FROM tblEmployee
WHERE LEN(Employee_FirstName) < 10;



--15

SELECT *
FROM tblEmployee
WHERE CHARINDEX('N', Employee_FirstName) > 0;

--16---

SELECT *
FROM tblEmployee
WHERE DATEDIFF(YEAR, JoiningDate, '2023-10-20') > 3;


--17

SELECT *
FROM tblEmployee

WHERE DATEPART(WEEKDAY, JoiningDate) = 6; -- Monday corresponds to 2 in SQL Server

 
--18

SELECT *
FROM tblEmployee
WHERE DAY(JoiningDate) = 1;

--19--

SELECT *
FROM tblEmployee
WHERE MONTH(JoiningDate) = 1


--20--
Select Employee_FirstName from tblEmployee
where Employee_FirstName like '% %'


 select * from tblEmployee

 --query 1 
 
 
 21--
 Select Employee_FirstName,JoiningDate, DATENAME(weekday,JoiningDate) as 'datename'
 from tblEmployee
 where  datename  (weekday , JoiningDate) = 'Sunday';


 --- Assignement 3


 1-- 1.Display all the employees data by sorting the date of joining in the ascending order and 
---then by name in descending order. 
 select *  from tblEmployee 
 order by JoiningDate asc, Employee_FirstName desc




 --2 ----2.Modify the column name EmployeeName to Employee_FirstName and also add another column Employee_LastName  
 ALTER TABLE tblEmployee
RENAME COLUMN EmployeeName as Employee_FirstName;

EXEC sp_rename 'tblEmployee.EmployeeName', 'Employee_FirstName', 'COLUMN';

 Alter table  tblEmployee 
 add  Employee_LastName VARCHAR(50);




 --- 3.Write a query to change the table name to Employees.
 
 
 EXEC sp_rename 'tblEmployee', 'Employees';



 --4 ---- Write a query to update the salary of those employees whose location is �Mysore� to 35000. 

 Update tblEmployee
 set salary =35000
 where DepartmentID in (select DepartmentID from tblDepartment where Location='mysore' );



 --5----Write a query to disassociate all trainees from their department  

 UPDATE tblEmployee
SET DepartmentID = NULL
WHERE Designation = 'Trainees Software Engineer';


--6----Write a query which adds another column �Bonus� to the table Employees where the bonus is equal to the salary multiplied by ten. Update the value only when the experience is two years or above. 

Alter  table  tblEmployee
add Bonus money;

update tblEmployee
set bonus = salary*10
where DATEDIFF (Year,JoiningDate, GETDATE())>=2;



--7---- Display name and salary of top 5 salaried employees from Mysore and Hyderabad. 

select Top 5 Employee_FirstName, salary 
from tblEmployee
----where location in ('mysore', 'hyderbad ')
order by salary desc


--8--- Display name and salary of top 3 salaried employees(Include employees with tie) 


       select top 3 with ties Salary, Employee_FirstName 
	   from  tblEmployee 
	   order by salary desc 


--9--- Display top 1% salaried employees from Noida and Bangalore 


select top 1 percent salary, Employee_FirstName from tblEmployee

where location in ('noida', 'bangalore')
order by salary desc 


--10----- Find average and total salary for each job. 

select designation , avg(salary), sum (salary)
from tblemployee
group by designation


--11------Find highest salary of all departments. 

select designation , max(salary)
from tblEmployee
group by designation 


--12 --- Find minimum salary of all departments. 

select designation , min(salary)
from tblEmployee
group by designation


--13 ---Find difference in highest and lowest salary for all departments. 

select (max(salary)-min(salary)) as diffrence_salary 
from tblemployee



--14----Find average and total salary for trainees 

 select avg(salary), sum(salary) from tblEmployee
where designation ='trainee software engineer'



--15---Count total different jobs held by dept no 30 

select count(distinct designation )
from tblEmployee
where DepartmentID=30



--16--- Find highest and lowest salary for non-managerial job 


select max(salary), min(salary) from tblEmployee
where designation='non managerial'




--17---- Count employees and  average annual salary of each department. 

select count(EmployeeID), avg(12*salary)
from tblEmployee
group by DepartmentID




--18----Display the number of employees sharing same joining date. 


select count(*) as countEmp, JoiningDate 
from tblEmployee
group by JoiningDate
having count(*)>1;



--19--- Display number of employees with same experience 

select  EmployeeName, DATEDIFF(YEAR, JoiningDate, getdate()) as experince  from tblEmployee
group by DATEDIFF(YEAR, JoiningDate, getdate())
having count(*)>1
order by experince 



--20--- Display total number of employees in each department with same salary 

SELECT count(EmployeeID) from tblEmployee
group by Designation, salary



--21 ---- Display the  number of Employees above 35 years in each department 

Select  count(*) as NosofSalary
from tblEmployee
where  datediff(year, joiningdate,GETDATE() )>35
group by DepartmentID






------Subqueries-----

-- Create the Salesman table
CREATE TABLE Salesman (
    Sid INT PRIMARY KEY,
    Sname VARCHAR(50),
    Location VARCHAR(50)
);

-- Insert data into the Salesman table
INSERT INTO Salesman (Sid, Sname, Location)
VALUES
    (1, 'John', 'New York'),
    (2, 'Mary', 'Los Angeles'),
    (3, 'David', 'Chicago'),
    (4, 'Sarah', 'San Francisco'),
    (5, 'Robert', 'Miami');

-- Create the Product table
CREATE TABLE Product (
    Prodid INT PRIMARY KEY,
    Pdesc VARCHAR(50),
    Price DECIMAL(10, 2),
    Category VARCHAR(50),
    Discount DECIMAL(5, 2)
);

-- Insert data into the Product table
INSERT INTO Product (Prodid, Pdesc, Price, Category, Discount)
VALUES
    (101, 'Laptop', 1000.00, 'Electronics', 0.10),
    (102, 'Smartphone', 500.00, 'Electronics', 0.05),
    (103, 'Camera', 800.00, 'Electronics', 0.08),
    (104, 'Shoes', 75.00, 'Fashion', 0.15),
    (105, 'Watch', 150.00, 'Fashion', 0.12);

-- Create the Sale table
CREATE TABLE Sale (
    Saleid INT PRIMARY KEY,
    Sid INT REFERENCES Salesman(Sid),
    Sldate DATE,
    Amount DECIMAL(10, 2)
);

-- Insert data into the Sale table
INSERT INTO Sale (Saleid, Sid, Sldate, Amount)
VALUES
    (201, 1, '2023-10-15', 1200.00),
    (202, 2, '2023-10-16', 600.00),
    (203, 3, '2023-10-17', 900.00),
    (204, 4, '2023-10-18', 100.00),
    (205, 5, '2023-10-19', 200.00);

-- Create the Saledetail table
CREATE TABLE Saledetail (
    Saleid INT REFERENCES Sale(Saleid),
    Prodid INT REFERENCES Product(Prodid),
    Quantity INT,
    PRIMARY KEY (Saleid, Prodid)
);

-- Insert data into the Saledetail table
INSERT INTO Saledetail (Saleid, Prodid, Quantity)
VALUES
    (201, 101, 2),
    (202, 102, 3),
    (203, 103, 1),
    (204, 104, 5),
    (205, 105, 2);


	---1  Display the sale id and date for most recent sale. 

	select sid, sldate from Sale
	where sldate=(select max(Sldate) from Sale )


	---2  Display the names of salesmen who have made at least 2 sales. 
	SELECT Sname
FROM Salesman
WHERE Sid IN (
    SELECT Sid
    FROM Sale
    GROUP BY Sid
    HAVING COUNT(*) >= 2
);

--3.	Display the product id and description of those products which are sold in minimum total quantity.
SELECT P.Prodid, P.Pdesc
FROM Product P
WHERE P.Prodid IN (
 SELECT Sd.Prodid
FROM Saledetail Sd
GROUP BY Sd.Prodid
HAVING SUM(Sd.Quantity) = (
SELECT MIN(TotalQuantity)
FROM (
		SELECT SUM(Sd2.Quantity) AS TotalQuantity
		FROM Saledetail Sd2
		GROUP BY Sd2.Prodid
							) AS MinTotalQuantity
													)
															);



--4.	Display SId, SName and Location of those salesmen who have total sales amount 
--greater than average sales amount of all the sales made. 
--Amount can be calculated from Price and Discount of Product and Quantity sold.
SELECT S.Sid, S.Sname, S.Location
FROM Salesman S
WHERE S.Sid IN ( SELECT S1.Sid
FROM Salesman S1 JOIN Sale Sa 
ON S1.Sid = Sa.Sid
INNER   JOIN Saledetail Sd
ON Sa.Saleid = Sd.Saleid
INNER JOIN Product P ON Sd.Prodid = P.Prodid
GROUP BY S1.Sid,S.Location
HAVING SUM((P.Price - P.Discount) * Sd.Quantity) >
( SELECT AVG(TotalSales)
FROM (
SELECT S2.Location, SUM((P2.Price - P2.Discount) * Sd2.Quantity) AS TotalSales
FROM Salesman S2
INNER JOIN Sale Sa2
ON S2.Sid = Sa2.Sid
INNER JOIN Saledetail Sd2
ON Sa2.Saleid = Sd2.Saleid
INNER JOIN Product P2 
ON Sd2.Prodid = P2.Prodid
GROUP BY S2.Location
            ) AS AvgSalesPerLocation
WHERE AvgSalesPerLocation.Location = S1.Location
										)
										);





--Corelated Subquery 
--5.Display the product id, category, description and price for those products whose 
--price is maximum in each category. 


SELECT p.Prodid, p.Category, p.Pdesc, p.Price
FROM Product p
WHERE p.Price = (
    SELECT MAX(p2.Price)
    FROM Product p2
    WHERE p2.Category = p.Category
);
                                                                                                                                                       

--- 6.Display the names of salesmen who have not made any sales. 


SELECT Sname
FROM Salesman
WHERE Sid NOT IN (
    SELECT DISTINCT Sid
    FROM Sale
);

--7.Display the names of salesmen who have made at least 1 sale in the month of 
---Jun 2015. 

SELECT DISTINCT Sname
FROM Salesman s
JOIN Sale sa ON s.Sid = sa.Sid
WHERE sa.Sldate >= '2015-06-01' AND sa.Sldate <= '2015-06-30';




--8.Display SId, SName and Location of those salesmen who have total sales 
--amount greater than average total sales amount of their location calculated per 
--salesman. Amount can be calculated from Price and Discount of Product and 
--Quantity sold. 

Select 

 select * from Salesman
 select * from Product
 select * from Saledetail
 select * from sale 





 ---------------------------------------------------------------------------------------------------------------
 ------------------------------------------------VEIWS--------------------------------------------------------
 -----------------------------------------------------------------------------------------------------------------

 CREATE TABLE Employe1 (
    EmployeeID INT PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    BirthDate DATE,
    Department VARCHAR(50),
    Salary DECIMAL(10, 2)
);

-- Insert sample data into the Employee table
INSERT INTO Employe1 (EmployeeID, FirstName, LastName, BirthDate, Department, Salary)
VALUES
    (1, 'John', 'Doe', '1985-03-15', 'HR', 55000.00),
    (2, 'Jane', 'Smith', '1990-07-20', 'IT', 60000.00),
    (3, 'Michael', 'Johnson', '1982-12-10', 'Sales', 62000.00),
    (4, 'Emily', 'Brown', '1988-05-25', 'Finance', 58000.00),
    (5, 'David', 'Wilson', '1995-02-03', 'IT', 62000.00);



	create view view_emp
	as
	select EmployeeID,FirstName, Department from Employe1
	where Salary>50000;

	select * from view_emp



	sp_helptext view_emp
	sp_refreshview  view_emp


	select  EmployeeID, firstname from view_emp

CREATE VIEW DemoView 
WITH SCHEMABINDING 
AS 
     SELECT * 
     FROM Employe1; 

	 CREATE VIEW DemoView 
WITH SCHEMABINDING 
AS 
     SELECT EmployeeID, firstname 
     FROM Employe1; 


	 CREATE VIEW DemoView 
WITH SCHEMABINDING 
AS 
     SELECT EmployeeID, firstname 
     FROM Employe1

	 CREATE VIEW DemoView 
WITH ENCRYPTION 
AS 
     SELECT EmployeeID, firstname 
     FROM Employe1

	 Exec sp_helptext DemoView


	 Insert into DemoView values(4,'CC','KK','RR') 
Delete from DemoView where EmployeeID=3 
Update DemoView set value='Raj' where EmployeeID=1 
 


 


	 ALTER TABLE Employe1 ALTER COLUMN EmployeeID BIGINT; 



	 ------------------------------------------------------------------------------------------------------------
	 -------------------------------------------TSQL------------------------------------------------------------
	 -----------------------------------------------------------------------------------------------------

	 ----1) Fibonacci Series

declare @a int
declare @b int
declare @c int
Declare @i int

set @a=0
set @b=1
set @i=0
set @c=0
Print 'Fibonacci Series'
print @a
print @b
while @i<10 
Begin
set @c=@a+@b
print @c
set @i=@i+1
set @a=@b
set @b=@c
end

--2 Create student and result table and perform the following: 
--.Write query to find the grade of a student, if he scores above 90 its 'A�, 
--above 80 'B', above 70 �C�, above 60 �D�, above 50 �F� or else print 
--failed.(Hint: Use Case ) 


-- creating the required tables
CREATE TABLE tblStudent (
    StudentID INT PRIMARY KEY,
    StudentName VARCHAR(50)
);


CREATE TABLE Result (
    StudentID INT,
    Score INT,
    FOREIGN KEY (StudentID) REFERENCES tblStudent(StudentID)
);
-- Insert sample data into the Student table
INSERT INTO tblStudent (StudentID, StudentName)
VALUES
    (1, 'Sagar'),
    (2, 'Arun'),
    (3, 'Nishanth');

-- Insert sample data into the Result table
INSERT INTO Result (StudentID, Score)
VALUES
    (1, 85),
    (2, 72),
    (3, 94);

	--3)
	SELECT
    s.StudentName,
    r.Score,
    CASE
        WHEN r.Score > 90 THEN 'A'
        WHEN r.Score > 80 THEN 'B'
        WHEN r.Score > 70 THEN 'C'
        WHEN r.Score > 60 THEN 'D'
        WHEN r.Score > 50 THEN 'F'
        ELSE 'Failed'
    END AS Grade
FROM tblStudent s
JOIN Result r ON s.StudentID = r.StudentID;



---4
-- Create the Employee table
CREATE TABLE Employee (
    EmployeeID INT PRIMARY KEY,
    EmployeeName VARCHAR(50),
    BirthDate DATE
);

-- Insert sample data into the Employee table
INSERT INTO Employee (EmployeeID, EmployeeName, BirthDate)
VALUES
    (1, 'John Cena', '1990-05-15'),
    (2, 'Dean Ambrose', '1988-08-22'),
    (3, 'Seth Rollins', '1995-02-10');


SELECT
    EmployeeName,
    BirthDate,
    CASE
        WHEN MONTH(BirthDate) = 1 THEN 'January'
        WHEN MONTH(BirthDate) = 2 THEN 'February'
        WHEN MONTH(BirthDate) = 3 THEN 'March'
        WHEN MONTH(BirthDate) = 4 THEN 'April'
        WHEN MONTH(BirthDate) = 5 THEN 'May'
        WHEN MONTH(BirthDate) = 6 THEN 'June'
        WHEN MONTH(BirthDate) = 7 THEN 'July'
        WHEN MONTH(BirthDate) = 8 THEN 'August'
        WHEN MONTH(BirthDate) = 9 THEN 'September'
        WHEN MONTH(BirthDate) = 10 THEN 'October'
        WHEN MONTH(BirthDate) = 11 THEN 'November'
        WHEN MONTH(BirthDate) = 12 THEN 'December'
        ELSE 'Invalid Month'
    END AS BirthMonth
FROM Employee;






--5





