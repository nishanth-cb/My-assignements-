﻿



With EmployeeCount(DepartmentId, TotalEmployees)​ as​

(​
	Select DepartmentId, COUNT(*) as TotalEmployees​
	from tblEmployee​1
	group by DepartmentId​
)​
SELECT * FROM EmployeeCount


WITH EmployeeCount(DepartmentId, TotalEmployees) AS
(
    SELECT DepartmentId, COUNT(*) as TotalEmployees
    FROM tblEmployee1
    GROUP BY DepartmentId
)
SELECT * FROM EmployeeCount


WITH EmployeesByDepartment AS
(SELECT   tblEmployee1.Id,   tblEmployee1.Name,    Gender,   tblDepartmen.DeptName
    FROM 
        tblEmployee1
    JOIN 
        tblDepartmen ON tblDepartmen.DeptId = tblEmployee1.DepartmentId
)
UPDATE EmployeesByDepartment 
SET Gender = 'Male' 
WHERE Id = 1;



With EmployeesByDepartment​
as​
(​
Select E.Id, E.Name, E.Gender, D.DeptName ​
from tblEmployee1 E
join tblDepartmen D
on D.DeptId = E.DepartmentId​
)​
Update EmployeesByDepartment set ​
DeptName = 'IT' where Id = 1


SELECT * FROM tblEmployee1
SELECT * FROM tblDepartmen


CREATE TABLE tblEmployee2
(
  EmployeeId int PRIMARY KEY,
  Name varchar(20),
  ManagerId int
);

INSERT INTO tblEmployee2(EmployeeId,Name, ManagerId) VALUES (1, 'Tom', 2),
                                 (2, 'Josh', null),
                                 (3, 'Mike', 2),
                                 (4, 'John', 3),
                                 (5, 'Pam', 1),
                                 (6, 'Mary', 3),
                                 (7, 'James', 1),
                                 (8, 'Sam', 5),
                                 (9, 'Simon', 1);




Select Employee.Name as [Employee Name],​
IsNull(Manager.Name, 'Super Boss') as [Manager Name]​
from tblEmployee2 Employee​
left join tblEmployee2 Manager​
on Employee.ManagerId = Manager.EmployeeId 


WITH EmpCTE(EmployeeId, Name, ManagerId, [level])
AS (
    SELECT EmployeeId, Name, ManagerId, 1
    FROM tblEmployee2
    WHERE ManagerId IS NULL

    UNION ALL

    SELECT E.EmployeeId, E.Name, E.ManagerId, EC.[level] + 1
    FROM tblEmployee2 E
    INNER JOIN EmpCTE EC ON E.ManagerId = EC.EmployeeId
)
SELECT E.Name AS EMPLOYEE, ISNULL(EC.Name, 'SUPER BOSS') AS MANAGER, EC.[level]
FROM EmpCTE E
LEFT JOIN EmpCTE EC ON E.ManagerId = EC.EmployeeId;




WITH EmployeeCount  
AS 
(
    SELECT DepartmentId, COUNT(*) AS TotalEmployees 
    FROM tblEmployee1 
    GROUP BY DepartmentId
)
 
SELECT d.DeptName, TotalEmployees 
FROM tblDepartmen d
JOIN EmployeeCount 
    ON d.DeptId = EmployeeCount.DepartmentId 
ORDER BY TotalEmployees;










SELECT * FROM tblEmployee2
|

--With​
--  EmployeesCTE (EmployeeId, Name, ManagerId, [Level])​
--  as​
--  (​
--    Select EmployeeId, Name, ManagerId, 1​
--    from tblEmployee​
--    where ManagerId is null​
--    ​
--    union all​
--    ​
--    Select tblEmployee.EmployeeId, tblEmployee.Name, ​
--    tblEmployee.ManagerId, EmployeesCTE.[Level] + 1​
--    from tblEmployee​
--    join EmployeesCTE​
--    on tblEmployee.ManagerID = EmployeesCTE.EmployeeId​
--  )​
--Select EmpCTE.Name as Employee, Isnull(MgrCTE.Name, 'Super Boss') as 
--Manager, ​
--EmpCTE.[Level] ​
--from EmployeesCTE EmpCTE​
--left join EmployeesCTE MgrCTE​
--on EmpCTE.ManagerId = MgrCTE.EmployeeId 
